<?php
$con = mysql_connect('localhost','root','4785c38b1a65aac9');
mysql_query("set names utf8");
mysql_select_db("ctf");
?>
