<!doctype html>
<html class="no-js" lang="">

<head>

    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1">

    <title>留言板</title>

<style type="text/css"> 
.AutoNewline 
{ 
  Word-break: break-all;
} 
</style>
    <link rel="stylesheet" href="/vendor/bootstrap-select/bootstrap-select.css">
    <link rel="stylesheet" href="/vendor/dropzone/dropzone.css">
    <link rel="stylesheet" href="/vendor/slider/slider.css">
    <link rel="stylesheet" href="/vendor/bootstrap-datepicker/datepicker.css">
    <link rel="stylesheet" href="/vendor/timepicker/jquery.timepicker.css">
    <link rel="stylesheet" href="/vendor/offline/theme.css">
    <link rel="stylesheet" href="/vendor/pace/theme.css">


    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/animate.min.css">

    <link rel="stylesheet" href="/css/panel.css">

    <link rel="stylesheet" href="/css/skins/palette.1.css" id="skin">
    <link rel="stylesheet" href="/css/fonts/style.1.css" id="font">
    <link rel="stylesheet" href="/css/main.css">

    <script src="/vendor/modernizr.js"></script>
</head>

<body>
   <div class="app">
            <section class="main-content">
                <div class="content-wrap">
                    <div class="row">
                        <div class="col-lg-12">
                                <section class="panel">
                                <header class="panel-heading"><font><font><b>留言板</b></font></font></header>
                                <div class="panel-body">
                                    <form method="post">
                                    <div class="demo-button">
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addmodal">发贴</button>
                                    </div>
                                    </form>
                                </div>
                                <li class="table_line"></li>
                                <div class="panel-group" id="accordion">
                                    <div class="panel">
                                            <div class="panel-body">
                                            <table class="table table-striped no-margin">
                                            <thead>
                                            <tr>
                                                <th class="col-lg-1">ID</th>
                                                <th class="col-lg-5">CATEGORY</th>
                                                <th class="col-lg-5">TITLE</th>
                                                <th class="col-lg-1"></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                
<?php
include "mysql.php";
    $sql = "select * from board";
    $result = mysql_query($sql);
    $num = mysql_num_rows($result);
    if($num>0){
    while($row= mysql_fetch_array($result)){
    echo '<tr>';
    echo "<td>$row[id]</td>";
    echo "<td class='AutoNewline'>$row[category]</td>";
    echo "<td class='AutoNewline'>$row[title]</td>";
    echo "
          <td>
          <form method='get' action='./comment.php'>
          <input hidden name='id' value='$row[id]'>
          <button class='btn btn-danger btn-xs' type='submit'>详情</button>      
          </form>
          </td>
         ";
    echo '</tr>';
    }
    }
?>
                                            </tbody>
                                            </table>
                                            </div>
                                    </div>
                                </div>
                            </section>
        </div>
        </div>
        </div>
</section>
<div class="modal fade bs-modal-md" id="addmodal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h5 class="modal-title text-center" id="myModalLabel">发贴</h5>
            </div>
            <div class="modal-body">
                        <form class="form-horizontal bordered-group" role="form" action="./write_do.php?do=write" method="post" onsubmit="return submit_check()">
                            <div class="form-group">
                                <label class="col-sm-2 control-label">TITLE</label>
                                <div class="col-sm-5">
                                <input type="text" class="form-control" name="title">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">CATEGORY</label>
                                <div class="col-sm-5">
                                <input type="text" class="form-control" name="category">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">CONTENT</label>
                                <div class="col-sm-5">
                                <input type="text" class="form-control" name="content">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary btn-sm">提交</button>
                            </div>
                        </form>
            </div>
        </div>
    </div>
</div>

</div>
    <script src="/vendor/jquery-1.11.1.min.js"></script>
    <script src="/bootstrap/js/bootstrap.js"></script>
    <script src="/vendor/jquery.easing.min.js"></script>
    <script src="/vendor/jquery.placeholder.js"></script>
    <script src="/vendor/fastclick.js"></script>


    <script src="/vendor/bootstrap-select/bootstrap-select.js"></script>
    <script src="/vendor/dropzone/dropzone.js"></script>
    <script src="/vendor/parsley.min.js"></script>
    <script src="/vendor/fuelux/checkbox.js"></script>
    <script src="/vendor/fuelux/radio.js"></script>
    <script src="/vendor/fuelux/wizard.js"></script>
    <script src="/vendor/fuelux/pillbox.js"></script>
    <script src="/vendor/fuelux/spinner.js"></script>
    <script src="/vendor/slider/bootstrap-slider.js"></script>
    <script src="/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
    <script src="/vendor/wysiwyg/jquery.hotkeys.js"></script>
    <script src="/vendor/wysiwyg/bootstrap-wysiwyg.js"></script>
    <script src="/vendor/switchery/switchery.js"></script>
    <script src="/vendor/timepicker/jquery.timepicker.js"></script>
    <script src="/vendor/offline/offline.min.js"></script>
    <script src="/vendor/pace/pace.min.js"></script>

    <script src="/vendor/jquery.slimscroll.js"></script>
    <script src="/js/off-canvas.js"></script>
    <script src="/js/main.js"></script>

    <script src="/js/panel.js"></script>
    <script src="/js/forms.js"></script>
<script language="javascript">  
function submit_check(){
    var gnl=confirm("确定要提交?");
    if (gnl==true){
        return true;
    }
    else{
        return false;
    }
    }
</script> 

</body>
</html>
