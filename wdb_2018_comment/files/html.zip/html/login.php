<!doctype html>
<html class="signin no-js" lang="">
<head>

    <meta charset="utf-8">
    <title>Login</title>

    <link rel="stylesheet" href="vendor/offline/theme.css">
    <link rel="stylesheet" href="vendor/pace/theme.css">


    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.min.css">


    <link rel="stylesheet" href="css/skins/palette.1.css" id="skin">
    <link rel="stylesheet" href="css/fonts/style.1.css" id="font">
    <link rel="stylesheet" href="css/main.css">

    <script src="vendor/modernizr.js"></script>
</head>

<body class="bg-color center-wrapper">
    <div class="center-content">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <section class="panel panel-default">
                    <header class="panel-heading">Sign in</header>
                    <div class="bg-white user pd-md">
                        <form role="form" action="login.php" method="post">
                            <input name="username" type="text" class="form-control mg-b-sm" placeholder="zhangwei" autofocus>
                            <input name="password" type="password" class="form-control" placeholder="zhangwei***">
                            <div class="text-right mg-b-sm mg-t-sm"></div>
                            <button class="btn btn-info btn-block" type="submit">Sign in</button>
                        </form>
                    </div>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
<?php
include "mysql.php";
session_start();
header("Content-type: text/html; charset=utf-8");
if(isset($_POST['username'])){
$username = addslashes($_POST['username']);
$password = addslashes($_POST['password']);
$sql = "select * from user where username='$username' and password='$password'";
$result = mysql_query($sql);
$num = mysql_num_rows($result);
if($num>0){
    $_SESSION['login'] = 'yes';
    header("Location: index.php");
}
else{
    echo '<script>alert("username or password error")</script>';
}
}
?>
